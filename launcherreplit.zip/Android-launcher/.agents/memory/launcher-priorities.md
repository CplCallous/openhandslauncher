---
name: Launcher priorities
description: Product priorities for the Android launcher.
---

Prioritize speed and customization. Keep launcher features independently configurable, and keep private folders difficult to discover and protected by a password.

**Why:** The user said speed is most important and explicitly requested granular settings plus a concealed, password-protected hidden-folders area.

**How to apply:** Favor a fast app list and low-friction navigation before optional integrations; do not expose private folders in ordinary settings navigation, and retain their PIN gate.
