import { Platform } from 'react-native';
import { requireOptionalNativeModule } from 'expo-modules-core';
import type { LauncherApp } from '@/data/launcher';

type NativeLauncherModule = {
  getInstalledApps(): Promise<LauncherApp[]>;
  launchApp(packageName: string): Promise<boolean>;
  openAppInfo(packageName: string): Promise<void>;
  uninstallApp(packageName: string): Promise<void>;
  openHomeSettings(): Promise<void>;
  openNotificationAccessSettings(): Promise<void>;
  hasNotificationAccess(): boolean;
  getNotificationPreviews(): Record<string, string>;
  setNotificationPreviewCollection(enabled: boolean): Promise<void>;
  openUsageAccessSettings(): Promise<void>;
  hasUsageAccess(): boolean;
  getMostUsedApps(): Promise<string[]>;
  openAccessibilitySettings(): Promise<void>;
  getAppIcon(packageName: string): Promise<string | null>;
  expandNotificationShade(): Promise<boolean>;
  hasLockService(): boolean;
  lockScreen(): Promise<boolean>;
};

export const nativeLauncher =
  Platform.OS === 'android'
    ? requireOptionalNativeModule<NativeLauncherModule>('SwiftLauncher')
    : null;

export const isNativeLauncherAvailable = Boolean(nativeLauncher);
