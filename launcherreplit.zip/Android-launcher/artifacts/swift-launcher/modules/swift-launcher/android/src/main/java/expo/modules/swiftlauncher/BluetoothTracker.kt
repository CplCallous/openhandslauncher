package expo.modules.swiftlauncher

import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import java.util.concurrent.ConcurrentHashMap

object BluetoothTracker {
  val connected = ConcurrentHashMap<String, String>()
  private var registered = false

  private val receiver = object : BroadcastReceiver() {
    override fun onReceive(context: Context?, intent: Intent?) {
      if (intent == null) return
      val device: BluetoothDevice? = if (Build.VERSION.SDK_INT >= 33) {
        intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
      } else {
        @Suppress("DEPRECATION")
        intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
      }
      if (device == null) return
      val address: String = device.address ?: return
      if (intent.action == BluetoothDevice.ACTION_ACL_CONNECTED) {
        connected[address] = safeName(device, address)
      } else if (intent.action == BluetoothDevice.ACTION_ACL_DISCONNECTED) {
        connected.remove(address)
      }
    }
  }

  private fun safeName(device: BluetoothDevice, fallback: String): String {
    return try {
      device.name ?: fallback
    } catch (_: SecurityException) {
      fallback
    }
  }

  @Synchronized
  fun start(context: Context) {
    if (registered) return
    val filter = IntentFilter()
    filter.addAction(BluetoothDevice.ACTION_ACL_CONNECTED)
    filter.addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED)
    val app = context.applicationContext
    if (Build.VERSION.SDK_INT >= 33) {
      app.registerReceiver(receiver, filter, Context.RECEIVER_EXPORTED)
    } else {
      app.registerReceiver(receiver, filter)
    }
    registered = true
  }
}
