const fs = require('fs');
const path = require('path');
const {
  withAndroidManifest,
  withDangerousMod,
} = require('@expo/config-plugins');

function hasCategory(filter, name) {
  return (filter.category || []).some((category) => category.$['android:name'] === name);
}

module.exports = function withSwiftLauncher(config) {
  config = withAndroidManifest(config, (config) => {
    const manifest = config.modResults.manifest;
    const activity = manifest.application[0].activity.find((item) =>
      item.$['android:name']?.endsWith('.MainActivity'),
    );

    if (activity) {
      const homeFilter = (activity['intent-filter'] || []).find(
        (filter) =>
          filter.action?.some((action) => action.$['android:name'] === 'android.intent.action.MAIN') &&
          hasCategory(filter, 'android.intent.category.HOME'),
      );
      if (!homeFilter) {
        activity['intent-filter'] = activity['intent-filter'] || [];
        activity['intent-filter'].push({
          action: [{ $: { 'android:name': 'android.intent.action.MAIN' } }],
          category: [
            { $: { 'android:name': 'android.intent.category.HOME' } },
            { $: { 'android:name': 'android.intent.category.DEFAULT' } },
          ],
        });
      }
    }

    const launcherIntent = {
      action: [{ $: { 'android:name': 'android.intent.action.MAIN' } }],
      category: [{ $: { 'android:name': 'android.intent.category.LAUNCHER' } }],
    };
    const existingQueries = manifest.queries || [];
    const mergedQueries = existingQueries.reduce(
      (merged, query) => ({
        package: [...(merged.package || []), ...(query.package || [])],
        provider: [...(merged.provider || []), ...(query.provider || [])],
        intent: [...(merged.intent || []), ...(query.intent || [])],
      }),
      {},
    );
    mergedQueries.intent = mergedQueries.intent || [];
    const alreadyCanSeeLaunchers = mergedQueries.intent.some((intent) =>
      intent.action?.some((action) => action.$['android:name'] === 'android.intent.action.MAIN') &&
      intent.category?.some((category) => category.$['android:name'] === 'android.intent.category.LAUNCHER'),
    );
    if (!alreadyCanSeeLaunchers) mergedQueries.intent.push(launcherIntent);
    for (const themeAction of ['org.adw.launcher.THEMES', 'com.novalauncher.THEME', 'com.gau.go.launcherex.theme']) {
      const known = mergedQueries.intent.some((intent) =>
        intent.action?.some((action) => action.$['android:name'] === themeAction),
      );
      if (!known) mergedQueries.intent.push({ action: [{ $: { 'android:name': themeAction } }] });
    }
    manifest.queries = [mergedQueries];

    manifest['uses-permission'] = manifest['uses-permission'] || [];
    if (!manifest['uses-permission'].some((item) => item.$['android:name'] === 'android.permission.PACKAGE_USAGE_STATS')) {
      manifest['uses-permission'].push({
        $: { 'android:name': 'android.permission.PACKAGE_USAGE_STATS' },
      });
    }
    for (const permission of [
      'android.permission.READ_CALENDAR',
      'android.permission.BLUETOOTH_CONNECT',
      'android.permission.BLUETOOTH',
    ]) {
      if (!manifest['uses-permission'].some((item) => item.$['android:name'] === permission)) {
        manifest['uses-permission'].push({ $: { 'android:name': permission } });
      }
    }
    if (!manifest['uses-permission'].some((item) => item.$['android:name'] === 'android.permission.EXPAND_STATUS_BAR')) {
      manifest['uses-permission'].push({
        $: { 'android:name': 'android.permission.EXPAND_STATUS_BAR' },
      });
    }

    const app = manifest.application[0];
    app.service = app.service || [];
    if (!app.service.some((service) => service.$['android:name'] === 'expo.modules.swiftlauncher.LauncherNotificationListener')) {
      app.service.push({
        $: {
          'android:name': 'expo.modules.swiftlauncher.LauncherNotificationListener',
          'android:label': 'Swift Launcher notification access',
          'android:permission': 'android.permission.BIND_NOTIFICATION_LISTENER_SERVICE',
          'android:exported': 'true',
        },
        'intent-filter': [
          { action: [{ $: { 'android:name': 'android.service.notification.NotificationListenerService' } }] },
        ],
      });
    }
    if (!app.service.some((service) => service.$['android:name'] === 'expo.modules.swiftlauncher.LauncherAccessibilityService')) {
      app.service.push({
        $: {
          'android:name': 'expo.modules.swiftlauncher.LauncherAccessibilityService',
          'android:label': 'Swift Launcher screen lock',
          'android:permission': 'android.permission.BIND_ACCESSIBILITY_SERVICE',
          'android:exported': 'false',
        },
        'intent-filter': [
          { action: [{ $: { 'android:name': 'android.accessibilityservice.AccessibilityService' } }] },
        ],
        'meta-data': [
          {
            $: {
              'android:name': 'android.accessibilityservice',
              'android:resource': '@xml/swift_launcher_accessibility',
            },
          },
        ],
      });
    }
    return config;
  });

  config = withDangerousMod(config, [
    'android',
    async (config) => {
      const xmlDir = path.join(config.modRequest.platformProjectRoot, 'app/src/main/res/xml');
      fs.mkdirSync(xmlDir, { recursive: true });
      fs.writeFileSync(
        path.join(xmlDir, 'swift_launcher_accessibility.xml'),
        `<accessibility-service xmlns:android="http://schemas.android.com/apk/res/android" android:accessibilityEventTypes="typeAllMask" android:accessibilityFeedbackType="feedbackGeneric" android:canRetrieveWindowContent="false" android:description="@string/app_name" android:notificationTimeout="100" android:accessibilityFlags="flagDefault" />`,
      );
      return config;
    },
  ]);
  return config;
};
