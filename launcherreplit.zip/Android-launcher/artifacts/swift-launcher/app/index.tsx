import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { createContext, useContext } from 'react';
import {
  AppState,
  Alert,
  BackHandler,
  FlatList,
  Image,
  Keyboard,
  Linking,
  Modal,
  PanResponder,
  Platform,
  PermissionsAndroid,
  Pressable,
  ScrollView,
  StatusBar,
  StyleSheet,
  Switch,
  Text as NativeText,
  TextInput,
  View,
  type LayoutChangeEvent,
  type TextProps,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Clipboard from 'expo-clipboard';
import * as DocumentPicker from 'expo-document-picker';
import { File, Paths } from 'expo-file-system';
import * as Font from 'expo-font';
import * as Haptics from 'expo-haptics';
import * as ImagePicker from 'expo-image-picker';
import * as Location from 'expo-location';
import * as SecureStore from 'expo-secure-store';
import * as ScreenOrientation from 'expo-screen-orientation';
import { Feather } from '@expo/vector-icons';
import { KeyboardAvoidingView } from 'react-native-keyboard-controller';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import {
  defaultLauncherData,
  defaultWellbeing,
  defaultWidget,
  demoApps,
  featureGroups,
  type FeatureKey,
  type LauncherApp,
  type LauncherData,
  type BluetoothRule,
  type LauncherFolder,
  type SwipeAction,
  type WidgetSettings,
} from '@/data/launcher';
import { isNativeLauncherAvailable, nativeLauncher, type CalendarEvent } from '@/lib/nativeLauncher';

const STORAGE_KEY = 'swift-launcher-state-v1';
const PIN_KEY = 'swift-launcher-pin-v1';
const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');
const FontContext = createContext<string | undefined>(undefined);

function Text(props: TextProps) {
  const family = useContext(FontContext);
  return <NativeText {...props} style={[family ? { fontFamily: family } : undefined, props.style]} />;
}

type Screen = 'home' | 'drawer' | 'settings' | 'advanced' | 'hidden' | 'security' | 'wellbeing' | 'bluetooth';
type DialogMode = 'rename' | 'folder' | 'pin' | 'unlock' | 'restore' | 'folder-apps' | 'widget' | 'swipe' | 'swipe-app' | 'iconpack' | 'bt-apps' | null;
type DrawerItem =
  | { kind: 'header'; key: string; title: string }
  | { kind: 'app'; key: string; app: LauncherApp };
type WeatherState =
  | { status: 'idle' }
  | { status: 'loading' }
  | { status: 'denied' }
  | { status: 'error' }
  | { status: 'ready'; temp: number; high: number; low: number; code: number; unit: string };
function formatDuration(ms: number): string {
  const totalMinutes = Math.round(ms / 60000);
  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;
  if (hours === 0) return `${minutes}m`;
  return `${hours}h ${minutes}m`;
}
const MUSIC_PATTERN = /(spotify|music|saavn|gaana|wynk|deezer|tidal|poweramp|podcast|audible|soundcloud|pandora|shazam|radio|audio)/i;
const HEADER_H = 40;
const ROW_H = 62;

function weatherInfo(code: number): { label: string; icon: keyof typeof Feather.glyphMap } {
  if (code === 0) return { label: 'Clear', icon: 'sun' };
  if (code <= 2) return { label: 'Partly cloudy', icon: 'cloud' };
  if (code === 3) return { label: 'Overcast', icon: 'cloud' };
  if (code === 45 || code === 48) return { label: 'Fog', icon: 'cloud' };
  if (code >= 51 && code <= 57) return { label: 'Drizzle', icon: 'cloud-drizzle' };
  if ((code >= 61 && code <= 67) || (code >= 80 && code <= 82)) return { label: 'Rain', icon: 'cloud-rain' };
  if ((code >= 71 && code <= 77) || code === 85 || code === 86) return { label: 'Snow', icon: 'cloud-snow' };
  if (code >= 95) return { label: 'Thunderstorm', icon: 'cloud-lightning' };
  return { label: 'Cloudy', icon: 'cloud' };
}
const platformNotes: Partial<Record<FeatureKey, string>> = {
  homeWidgets: 'A home-screen widget host needs native Android widget support.',
  iconPacks: 'Icon pack discovery and rendering depend on Android icon-pack support.',
  landscape: 'Orientation changes depend on the Android activity configuration.',
  bluetoothShortcuts: 'Bluetooth shortcuts require device connection access.',
};
const unavailableInBuild: Partial<Record<FeatureKey, string>> = {
  mediaPlayer: 'Media session controls are not implemented in this build.',
  quickReplies: 'Notification reply actions are not implemented in this build.',
  homeWidgets: 'Android widget hosting is not implemented in this build.',
  popUps: 'App pop-up windows are not implemented in this build.',
};

type AppRowProps = {
  app: LauncherApp;
  label: string;
  iconUri?: string;
  notification?: string;
  favorite?: boolean;
  showIcons: boolean;
  colors: ReturnType<typeof useColors>;
  onPress: () => void;
  onLongPress: () => void;
  onSwipe?: () => void;
  iconPack?: string;
};

const appIconCache = new Map<string, string>();

function AppRow({
  app,
  label,
  iconUri,
  notification,
  favorite,
  showIcons,
  colors,
  onPress,
  onLongPress,
  onSwipe,
  iconPack,
}: AppRowProps) {
  const swipeRef = useRef(onSwipe);
  useEffect(() => {
    swipeRef.current = onSwipe;
  }, [onSwipe]);
  const swipePan = useMemo(
    () =>
      PanResponder.create({
        onMoveShouldSetPanResponder: (_, gesture) =>
          Boolean(swipeRef.current) && Math.abs(gesture.dx) > 24 && Math.abs(gesture.dx) > Math.abs(gesture.dy) * 2,
        onPanResponderTerminationRequest: () => false,
        onPanResponderRelease: (_, gesture) => {
          if (Math.abs(gesture.dx) > 70) swipeRef.current?.();
        },
      }),
    [],
  );
  const baseIconKey = `${iconPack || ''}:${app.packageName}`;
  const [nativeIcon, setNativeIcon] = useState<string | null>(
    () => appIconCache.get(baseIconKey) || null,
  );
  useEffect(() => {
    if (iconUri || !nativeLauncher) return;
    const cached = appIconCache.get(baseIconKey);
    if (cached) {
      setNativeIcon(cached);
      return;
    }
    const bridge = nativeLauncher;
    let mounted = true;
    const basePackage = app.packageName.split('@')[0];
    const load = async () => {
      let icon: string | null = null;
      if (iconPack) icon = await bridge.getIconPackIcon(iconPack, basePackage).catch(() => null);
      if (!icon) icon = await bridge.getAppIcon(basePackage).catch(() => null);
      if (icon && mounted) {
        appIconCache.set(baseIconKey, icon);
        setNativeIcon(icon);
      }
    };
    void load();
    return () => {
      mounted = false;
    };
  }, [app.packageName, iconUri, iconPack, baseIconKey]);
  const initials = label.trim().slice(0, 2).toUpperCase();
  const hue = app.packageName.split('').reduce((total, char) => total + char.charCodeAt(0), 0) % 5;
  const fills = [colors.accent, colors.secondary, colors.card, colors.muted, colors.primary];
  return (
    <View {...swipePan.panHandlers}>
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={`${label}${favorite ? ', favorite' : ''}`}
      onPress={onPress}
      onLongPress={onLongPress}
      delayLongPress={360}
      style={({ pressed }) => [styles.appRow, pressed && styles.pressed]}
    >
      {showIcons ? (
        <View style={[styles.appIcon, { backgroundColor: fills[hue] }]}>
          {iconUri || nativeIcon ? (
            <Image source={{ uri: iconUri || nativeIcon || undefined }} style={styles.appIconImage} resizeMode="contain" />
          ) : (
            <Text style={[styles.appInitials, { color: hue === 4 ? colors.primaryForeground : colors.accentForeground }]}>
              {initials}
            </Text>
          )}
        </View>
      ) : null}
      <View style={styles.appNameColumn}>
        <View style={styles.appNameLine}>
          <Text numberOfLines={1} style={[styles.appName, { color: colors.foreground }]}>
            {label}
          </Text>
          {favorite ? <Feather name="star" size={14} color={colors.primary} /> : null}
        </View>
        {notification ? (
          <Text numberOfLines={1} style={[styles.notificationText, { color: colors.mutedForeground }]}>
            {notification}
          </Text>
        ) : null}
      </View>
      <View style={styles.rowTouchMark}>
        <Feather name="chevron-right" size={16} color={colors.mutedForeground} />
      </View>
    </Pressable>
    </View>
  );
}

export default function LauncherScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const [screen, setScreen] = useState<Screen>('home');
  const [data, setData] = useState<LauncherData>(defaultLauncherData);
  const [loaded, setLoaded] = useState(false);
  const [apps, setApps] = useState<LauncherApp[]>([]);
  const [isDemo, setIsDemo] = useState(false);
  const [appError, setAppError] = useState('');
  const [search, setSearch] = useState('');
  const [hiddenAppSearch, setHiddenAppSearch] = useState('');
  const [appMenu, setAppMenu] = useState<LauncherApp | null>(null);
  const [dialog, setDialog] = useState<DialogMode>(null);
  const [draft, setDraft] = useState('');
  const [pinEntry, setPinEntry] = useState('');
  const [pin, setPin] = useState<string | null>(null);
  const [pinPurpose, setPinPurpose] = useState<'hidden' | 'app' | 'remove' | 'change' | null>(null);
  const [pendingApp, setPendingApp] = useState<LauncherApp | null>(null);
  const [folderTarget, setFolderTarget] = useState<string | null>(null);
  const [hiddenOpen, setHiddenOpen] = useState(false);
  const [hiddenRevealCount, setHiddenRevealCount] = useState(0);
  const [activeFolder, setActiveFolder] = useState<LauncherFolder | null>(null);
  const [recentIds, setRecentIds] = useState<string[]>([]);
  const [suggestedIds, setSuggestedIds] = useState<string[]>([]);
  const [notifications, setNotifications] = useState<Record<string, string>>({});
  const [iconUris, setIconUris] = useState<Record<string, string>>({});
  const [customFontFamily, setCustomFontFamily] = useState<string | null>(null);
  const [scrubberHeight, setScrubberHeight] = useState(0);
  const [time, setTime] = useState(() => new Date());
  const [settingSearch, setSettingSearch] = useState('');
  const [appPickerFolderId, setAppPickerFolderId] = useState<string | null>(null);
  const [calculatorValue, setCalculatorValue] = useState('');
  const [calculatorOpen, setCalculatorOpen] = useState(false);
  const [weather, setWeather] = useState<WeatherState>({ status: 'idle' });
  const [scrubLetter, setScrubLetter] = useState<string | null>(null);
  const [agenda, setAgenda] = useState<CalendarEvent[]>([]);
  const [calendarGranted, setCalendarGranted] = useState(false);
  const [usageToday, setUsageToday] = useState<Record<string, number>>({});
  const [btConnected, setBtConnected] = useState<Array<{ address: string; name: string }>>([]);
  const [btPaired, setBtPaired] = useState<Array<{ address: string; name: string }>>([]);
  const [btAllowed, setBtAllowed] = useState(false);
  const [btTarget, setBtTarget] = useState<{ address: string; name: string } | null>(null);
  const [headphones, setHeadphones] = useState(false);
  const [iconPackList, setIconPackList] = useState<Array<{ packageName: string; name: string }>>([]);
  const lastBreakAlert = useRef(0);
  const lastClockTap = useRef(0);
  const drawerList = useRef<FlatList<DrawerItem>>(null);
  const scrubberRef = useRef<View>(null);
  const scrubberTop = useRef(0);
  const lastScrubSlot = useRef(-1);

  const persist = useCallback((next: LauncherData) => {
    setData(next);
    void AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(next)).catch(() => {
      Alert.alert('Could not save changes', 'Storage is unavailable. Your latest changes may not be saved.');
    });
  }, []);

  useEffect(() => {
    let active = true;
    const load = async () => {
      try {
        const stored = await AsyncStorage.getItem(STORAGE_KEY);
        let savedPin: string | null = null;
        if (Platform.OS !== 'web') {
          try {
            savedPin = await SecureStore.getItemAsync(PIN_KEY);
          } catch {
            savedPin = null;
          }
        }
        if (!active) return;
        if (stored) {
          const parsed = JSON.parse(stored) as Partial<LauncherData>;
          const savedFavorites = Array.isArray(parsed.favorites) ? parsed.favorites : [];
          setData({
            ...defaultLauncherData,
            ...parsed,
            favorites:
              savedFavorites.length > 0 || parsed.favoritesConfigured
                ? savedFavorites
                : defaultLauncherData.favorites,
            settings: { ...defaultLauncherData.settings, ...(parsed.settings || {}) },
            widget: { ...defaultWidget, ...(parsed.widget || {}) },
            wellbeing: { ...defaultWellbeing, ...(parsed.wellbeing || {}) },
          });
          if (parsed.customFontUri && parsed.customFontFamily) {
            try {
              await Font.loadAsync({ [parsed.customFontFamily]: { uri: parsed.customFontUri } });
              if (active) setCustomFontFamily(parsed.customFontFamily);
            } catch {
              if (active) Alert.alert('Custom font unavailable', 'Choose the font file again to use it.');
            }
          }
        }
        setPin(savedPin);
      } catch {
        if (active) Alert.alert('Could not load launcher settings', 'Saved preferences could not be read.');
      } finally {
        if (active) {
          setLoaded(true);
          setIsDemo(!isNativeLauncherAvailable);
        }
      }
    };
    void load();
    return () => {
      active = false;
    };
  }, []);

  const dualAppsEnabled = data.settings.dualApps;

  useEffect(() => {
    if (isNativeLauncherAvailable && nativeLauncher) {
      const bridge = nativeLauncher;
      void bridge
        .getInstalledApps()
        .then(async (installed) => {
          let extra: LauncherApp[] = [];
          if (dualAppsEnabled) {
            try {
              const profileApps = await bridge.getProfileApps();
              extra = profileApps.map((item) => ({
                packageName: `${item.packageName}@${item.profile}`,
                name: `${item.name} (Dual)`,
              }));
            } catch {
              extra = [];
            }
          }
          setApps([...installed, ...extra]);
          setAppError('');
        })
        .catch(() => setAppError('Android could not read the installed app list. Check app visibility permissions.'));
    } else {
      setApps(demoApps);
    }
  }, [isNativeLauncherAvailable, dualAppsEnabled]);

  useEffect(() => {
    if (!loaded || !isNativeLauncherAvailable || apps.length === 0) return;
    if (!data.favoritesConfigured) {
      const preferredNames = ['Camera', 'Chrome', 'Phone', 'Messages', 'Maps', 'Photos'];
      const preferred = preferredNames
        .map((name) => apps.find((app) => app.name.toLocaleLowerCase() === name.toLowerCase()))
        .filter((app): app is LauncherApp => Boolean(app))
        .map((app) => app.packageName);
      const nextFavorites = [...new Set([...preferred, ...apps.map((app) => app.packageName)])].slice(0, 6);
      persist({ ...data, favorites: nextFavorites, favoritesConfigured: true });
      return;
    }
    const currentFavorites = data.favorites.filter(
      (id) => id.includes('@') || apps.some((app) => app.packageName === id),
    );
    if (currentFavorites.length !== data.favorites.length) {
      persist({ ...data, favorites: currentFavorites });
    }
  }, [apps, data, isNativeLauncherAvailable, loaded, persist]);

  useEffect(() => {
    if (loaded) void AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  }, [data, loaded]);

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 30_000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    if (Platform.OS === 'web') return;
    const orientation = data.settings.landscape
      ? ScreenOrientation.OrientationLock.DEFAULT
      : ScreenOrientation.OrientationLock.PORTRAIT_UP;
    void ScreenOrientation.lockAsync(orientation).catch(() => {
      Alert.alert('Orientation unavailable', 'Android did not allow the requested screen orientation.');
    });
  }, [data.settings.landscape]);

  useEffect(() => {
    if (data.settings.suggestions && nativeLauncher?.hasUsageAccess()) {
      void nativeLauncher.getMostUsedApps().then(setSuggestedIds).catch(() => setSuggestedIds([]));
    }
  }, [data.settings.suggestions]);

  const needNotifications = data.settings.notificationPreviews || data.settings.notificationSummary;

  useEffect(() => {
    const bridge = nativeLauncher;
    if (!bridge || !needNotifications) return;
    const refresh = () => {
      try {
        if (bridge.hasNotificationAccess()) setNotifications(bridge.getNotificationPreviews());
      } catch {
        setNotifications({});
      }
    };
    refresh();
    const timer = setInterval(refresh, 10_000);
    const subscription = AppState.addEventListener('change', (state) => {
      if (state === 'active') refresh();
    });
    return () => {
      clearInterval(timer);
      subscription.remove();
    };
  }, [needNotifications]);

  useEffect(() => {
    if (!nativeLauncher) return;
    void nativeLauncher
      .setNotificationPreviewCollection(needNotifications)
      .catch(() => undefined);
  }, [needNotifications]);

  const needCalendar = data.settings.calendarAgenda || data.settings.calendarPreview;

  const loadAgenda = useCallback(async () => {
    if (!nativeLauncher) return;
    try {
      const granted = nativeLauncher.hasCalendarPermission();
      setCalendarGranted(granted);
      if (!granted) {
        setAgenda([]);
        return;
      }
      const now = Date.now();
      const events = await nativeLauncher.getCalendarEvents(now - 60 * 60 * 1000, now + 3 * 24 * 60 * 60 * 1000);
      setAgenda(events.filter((event) => event.end > now).slice(0, 8));
    } catch {
      setAgenda([]);
    }
  }, []);

  const requestCalendarAccess = async () => {
    if (Platform.OS !== 'android') return;
    try {
      const result = await PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.READ_CALENDAR);
      if (result === PermissionsAndroid.RESULTS.GRANTED) {
        void loadAgenda();
      } else {
        Alert.alert('Calendar access needed', 'Allow calendar access for Swift Launcher in Android settings to see upcoming events.');
      }
    } catch {
      Alert.alert('Could not ask for calendar access', 'Open Android settings and allow calendar access for Swift Launcher.');
    }
  };

  useEffect(() => {
    if (!loaded || !needCalendar) return;
    void loadAgenda();
    const timer = setInterval(() => void loadAgenda(), 5 * 60 * 1000);
    const subscription = AppState.addEventListener('change', (state) => {
      if (state === 'active') void loadAgenda();
    });
    return () => {
      clearInterval(timer);
      subscription.remove();
    };
  }, [needCalendar, loaded, loadAgenda]);

  const needUsage = data.settings.digitalWellbeing || data.settings.usageBreaker;
  const breakerEnabled = data.settings.usageBreaker;
  const breakerMinutes = data.wellbeing.dailyLimitMinutes;

  const loadUsage = useCallback(async () => {
    if (!nativeLauncher) return;
    try {
      if (!nativeLauncher.hasUsageAccess()) return;
      const usage = await nativeLauncher.getUsageToday();
      setUsageToday(usage);
      if (breakerEnabled) {
        const total = Object.values(usage).reduce((sum, ms) => sum + ms, 0);
        if (total >= breakerMinutes * 60000 && Date.now() - lastBreakAlert.current > 60 * 60 * 1000) {
          lastBreakAlert.current = Date.now();
          Alert.alert('Time for a break', `You have spent ${formatDuration(total)} in apps today. Take a moment away from your phone.`);
        }
      }
    } catch {
      setUsageToday({});
    }
  }, [breakerEnabled, breakerMinutes]);

  useEffect(() => {
    if (!loaded || !needUsage) return;
    void loadUsage();
    const timer = setInterval(() => void loadUsage(), 5 * 60 * 1000);
    const subscription = AppState.addEventListener('change', (state) => {
      if (state === 'active') void loadUsage();
    });
    return () => {
      clearInterval(timer);
      subscription.remove();
    };
  }, [needUsage, loaded, loadUsage]);

  useEffect(() => {
    if (screen === 'wellbeing') void loadUsage();
  }, [screen, loadUsage]);

  const needConnections = data.settings.bluetoothShortcuts || data.settings.musicApps;

  useEffect(() => {
    const bridge = nativeLauncher;
    if (!loaded || !bridge || !needConnections) return;
    const poll = () => {
      try {
        setBtConnected(bridge.getConnectedBluetoothDevices());
        setHeadphones(bridge.hasHeadphones());
      } catch {
        setBtConnected([]);
        setHeadphones(false);
      }
    };
    poll();
    const timer = setInterval(poll, 8_000);
    const subscription = AppState.addEventListener('change', (state) => {
      if (state === 'active') poll();
    });
    return () => {
      clearInterval(timer);
      subscription.remove();
    };
  }, [needConnections, loaded]);

  const requestBluetoothAccess = useCallback(async (): Promise<boolean> => {
    if (Platform.OS !== 'android') return false;
    try {
      if (Number(Platform.Version) < 31) {
        setBtAllowed(true);
        return true;
      }
      const result = await PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.BLUETOOTH_CONNECT);
      const granted = result === PermissionsAndroid.RESULTS.GRANTED;
      setBtAllowed(granted);
      if (!granted) Alert.alert('Bluetooth access needed', 'Allow nearby devices access for Swift Launcher in Android settings to list your paired devices.');
      return granted;
    } catch {
      return false;
    }
  }, []);

  const loadPairedDevices = useCallback(async () => {
    if (!nativeLauncher) return;
    const granted = await requestBluetoothAccess();
    if (!granted) return;
    try {
      setBtPaired(await nativeLauncher.getBondedBluetoothDevices());
    } catch {
      setBtPaired([]);
    }
  }, [requestBluetoothAccess]);

  useEffect(() => {
    if (screen === 'bluetooth') void loadPairedDevices();
  }, [screen, loadPairedDevices]);

  const openIconPackPicker = async () => {
    if (!nativeLauncher) {
      Alert.alert('Android build required', 'Icon packs are available in the installed Android launcher.');
      return;
    }
    try {
      const packs = await nativeLauncher.getIconPacks();
      setIconPackList(packs);
      if (packs.length === 0) {
        Alert.alert('No icon packs found', 'Install an ADW or Nova compatible icon pack from the Play Store, then open this picker again.');
        return;
      }
      setDialog('iconpack');
    } catch {
      Alert.alert('Could not read icon packs', 'Android did not allow the launcher to list installed icon packs.');
    }
  };

  const loadWeather = useCallback(async (askPermission: boolean) => {
    try {
      setWeather((current) => (current.status === 'ready' ? current : { status: 'loading' }));
      let permission = await Location.getForegroundPermissionsAsync();
      if (!permission.granted && askPermission) {
        permission = await Location.requestForegroundPermissionsAsync();
      }
      if (!permission.granted) {
        setWeather({ status: 'denied' });
        return;
      }
      const position =
        (await Location.getLastKnownPositionAsync()) ??
        (await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Low }));
      if (!position) {
        setWeather({ status: 'error' });
        return;
      }
      const fahrenheit = (Intl.DateTimeFormat().resolvedOptions().locale || '').endsWith('-US');
      const url =
        'https://api.open-meteo.com/v1/forecast' +
        `?latitude=${position.coords.latitude.toFixed(2)}&longitude=${position.coords.longitude.toFixed(2)}` +
        '&current=temperature_2m,weather_code&daily=temperature_2m_max,temperature_2m_min' +
        `&forecast_days=1&timezone=auto${fahrenheit ? '&temperature_unit=fahrenheit' : ''}`;
      const response = await fetch(url);
      if (!response.ok) throw new Error('weather request failed');
      const json = await response.json();
      setWeather({
        status: 'ready',
        temp: Math.round(json.current.temperature_2m),
        code: Number(json.current.weather_code),
        high: Math.round(json.daily.temperature_2m_max[0]),
        low: Math.round(json.daily.temperature_2m_min[0]),
        unit: fahrenheit ? '°F' : '°C',
      });
    } catch {
      setWeather({ status: 'error' });
    }
  }, []);

  useEffect(() => {
    if (!loaded || !data.settings.weather) return;
    void loadWeather(false);
    const timer = setInterval(() => void loadWeather(false), 30 * 60 * 1000);
    return () => clearInterval(timer);
  }, [data.settings.weather, loaded, loadWeather]);

  useEffect(() => {
    if (Platform.OS === 'web') return;
    const subscription = BackHandler.addEventListener('hardwareBackPress', () => {
      if (calculatorOpen) {
        setCalculatorOpen(false);
        return true;
      }
      if (dialog) {
        Keyboard.dismiss();
        setDialog(null);
        return true;
      }
      if (appMenu) {
        setAppMenu(null);
        return true;
      }
      if (activeFolder) {
        setActiveFolder(null);
        return true;
      }
      if (screen !== 'home') {
        if (screen === 'hidden') {
          setHiddenOpen(false);
          setActiveFolder(null);
        }
        const target: Screen =
          screen === 'hidden' || screen === 'security' ? 'advanced' : screen === 'advanced' || screen === 'wellbeing' || screen === 'bluetooth' ? 'settings' : 'home';
        setScreen(target);
        setSearch('');
        Keyboard.dismiss();
        return true;
      }
      // A launcher is the bottom of the stack: Back on the home screen does nothing.
      return true;
    });
    return () => subscription.remove();
  }, [activeFolder, appMenu, calculatorOpen, dialog, screen]);

  const visibleApps = useMemo(() => {
    const query = search.trim().toLocaleLowerCase();
    return apps
      .filter((app) => !data.hiddenApps.includes(app.packageName))
      .filter((app) => !query || (data.renamedApps[app.packageName] || app.name).toLocaleLowerCase().includes(query))
      .sort((a, b) =>
        (data.renamedApps[a.packageName] || a.name).localeCompare(
          data.renamedApps[b.packageName] || b.name,
          undefined,
          { sensitivity: 'base' },
        ),
      );
  }, [apps, data.hiddenApps, data.renamedApps, search]);

  const sections = useMemo(() => {
    const groups = new Map<string, LauncherApp[]>();
    for (const app of visibleApps) {
      const label = data.renamedApps[app.packageName] || app.name;
      const letter = label.trim().charAt(0).toLocaleUpperCase() || '#';
      const section = /^[A-Z]$/.test(letter) ? letter : '#';
      groups.set(section, [...(groups.get(section) || []), app]);
    }
    return [...groups.entries()].map(([title, sectionApps]) => ({ title, data: sectionApps }));
  }, [data.renamedApps, visibleApps]);

  const favoriteApps = useMemo(
    () =>
      data.favorites
        .map((id) => apps.find((app) => app.packageName === id))
        .filter((app): app is LauncherApp => Boolean(app) && !data.hiddenApps.includes(app!.packageName)),
    [apps, data.favorites, data.hiddenApps],
  );
  const visibleFolders = data.folders.filter((folder) => !folder.hidden);
  const hiddenFolders = data.folders.filter((folder) => folder.hidden);
  const settingQuery = settingSearch.trim().toLowerCase();

  const displayName = (app: LauncherApp) => data.renamedApps[app.packageName] || app.name;

  const changeData = (mutate: (current: LauncherData) => LauncherData) => {
    persist(mutate(data));
  };

  const openDrawer = () => {
    setSearch('');
    Keyboard.dismiss();
    setScreen('drawer');
  };

  const goHome = () => {
    setScreen('home');
    setSearch('');
    setHiddenOpen(false);
    setActiveFolder(null);
    Keyboard.dismiss();
  };

  const openPinDialog = (purpose: 'hidden' | 'app') => {
    setPinPurpose(purpose);
    setPinEntry('');
    setDialog(pin ? 'unlock' : 'pin');
  };

  const launch = async (app: LauncherApp) => {
    if (data.settings.appPassword && data.lockedApps.includes(app.packageName)) {
      setPendingApp(app);
      openPinDialog('app');
      return;
    }
    if (nativeLauncher) {
      try {
        const [basePackage, profileSerial] = app.packageName.split('@');
        const opened = profileSerial
          ? await nativeLauncher.launchProfileApp(basePackage, Number(profileSerial))
          : await nativeLauncher.launchApp(app.packageName);
        if (!opened) Alert.alert('App unavailable', `${displayName(app)} does not have a launchable activity.`);
      } catch {
        Alert.alert('Could not open app', 'Android did not allow the app to open.');
      }
    } else {
      Alert.alert('Android build required', 'Opening installed apps is available in the installed Android launcher build.');
    }
    setRecentIds((current) => [app.packageName, ...current.filter((id) => id !== app.packageName)].slice(0, 8));
  };

  const launchWithPin = async () => {
    if (!pin || pinEntry !== pin) {
      setPinEntry('');
      Alert.alert('Incorrect PIN', 'Try entering your PIN again.');
      return;
    }
    if (pinPurpose === 'remove') {
      await removePin();
      return;
    }
    if (pinPurpose === 'change') {
      setPinEntry('');
      setDialog('pin');
      return;
    }
    setDialog(null);
    if (pinPurpose === 'hidden') {
      setHiddenOpen(true);
      setScreen('hidden');
    } else if (pendingApp && nativeLauncher) {
      await nativeLauncher.launchApp(pendingApp.packageName);
      setPendingApp(null);
    }
  };

  const removePin = async () => {
    try {
      await SecureStore.deleteItemAsync(PIN_KEY);
    } catch {
      Alert.alert('Could not remove PIN', 'Secure storage is unavailable. Try again in a moment.');
      return;
    }
    setPin(null);
    setPinEntry('');
    setDialog(null);
    setPinPurpose(null);
    changeData((current) => ({
      ...current,
      lockedApps: [],
      settings: { ...current.settings, appPassword: false },
    }));
    Alert.alert('PIN removed', 'Apps are no longer PIN-protected. Private folders will ask you to create a new PIN when you open them.');
  };

  const saveNewPin = async () => {
    if (!/^\d{4,8}$/.test(pinEntry)) {
      Alert.alert('Choose a 4–8 digit PIN', 'Use digits only.');
      return;
    }
    try {
      await SecureStore.setItemAsync(PIN_KEY, pinEntry);
    } catch {
      Alert.alert('Secure storage unavailable', 'Set a PIN from the installed Android launcher so it can be protected securely.');
      return;
    }
    setPin(pinEntry);
    setDialog(null);
    if (pinPurpose === 'change') Alert.alert('PIN changed', 'Your new PIN is active.');
    if (pinPurpose === 'hidden') {
      setHiddenOpen(true);
      setScreen('hidden');
    }
  };

  const toggleFavorite = (app: LauncherApp) => {
    changeData((current) => ({
      ...current,
      favoritesConfigured: true,
      favorites: current.favorites.includes(app.packageName)
        ? current.favorites.filter((id) => id !== app.packageName)
        : [...current.favorites, app.packageName],
    }));
    setAppMenu(null);
  };

  const toggleHiddenApp = (app: LauncherApp) => {
    const hide = !data.hiddenApps.includes(app.packageName);
    changeData((current) => ({
      ...current,
      hiddenApps: hide
        ? [...current.hiddenApps, app.packageName]
        : current.hiddenApps.filter((id) => id !== app.packageName),
    }));
    setAppMenu(null);
  };

  const saveRename = () => {
    if (!appMenu || !draft.trim()) return;
    changeData((current) => ({
      ...current,
      renamedApps: { ...current.renamedApps, [appMenu.packageName]: draft.trim() },
    }));
    setDialog(null);
    setAppMenu(null);
  };

  const createFolder = (hidden: boolean) => {
    const appId = folderTarget;
    const name = draft.trim();
    if (!name) {
      Alert.alert('Add a folder name', 'Folder names cannot be empty.');
      return;
    }
    const folder: LauncherFolder = {
      id: `folder-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      name,
      appIds: appId ? [appId] : [],
      hidden,
    };
    changeData((current) => ({ ...current, folders: [...current.folders, folder] }));
    setDialog(null);
    setAppMenu(null);
    setFolderTarget(null);
    setDraft('');
  };

  const moveToFolder = (folder: LauncherFolder) => {
    if (!appMenu) return;
    changeData((current) => ({
      ...current,
      folders: current.folders.map((item) =>
        item.id === folder.id && !item.appIds.includes(appMenu.packageName)
          ? { ...item, appIds: [...item.appIds, appMenu.packageName] }
          : item,
      ),
    }));
    setAppMenu(null);
    setDialog(null);
  };

  const chooseCustomIcon = async () => {
    const app = appMenu;
    if (!app) return;
    try {
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ['images'],
        allowsEditing: true,
        aspect: [1, 1],
        quality: 0.8,
      });
      if (!result.canceled && result.assets[0]?.uri) {
        changeData((current) => ({
          ...current,
          customIcons: { ...current.customIcons, [app.packageName]: result.assets[0].uri },
        }));
      }
    } catch {
      Alert.alert('Could not open photos', 'Allow photo access to choose a custom app icon.');
    }
    setAppMenu(null);
  };

  const chooseCustomFont = async () => {
    if (Platform.OS === 'web') {
      Alert.alert('Android device required', 'Choose a .ttf or .otf font file from the installed Android launcher.');
      return;
    }
    try {
      const result = await DocumentPicker.getDocumentAsync({
        type: ['font/ttf', 'font/otf', 'application/x-font-ttf', 'application/vnd.ms-opentype'],
        copyToCacheDirectory: true,
      });
      if (result.canceled || !result.assets[0]) return;
      const asset = result.assets[0];
      const extension = asset.name.toLowerCase().endsWith('.otf') ? '.otf' : '.ttf';
      const destination = new File(Paths.document, `swift-launcher-${Date.now()}${extension}`);
      await new File(asset.uri).copy(destination);
      const family = `SwiftFont_${Date.now()}`;
      await Font.loadAsync({ [family]: { uri: destination.uri } });
      setCustomFontFamily(family);
      changeData((current) => ({
        ...current,
        customFontUri: destination.uri,
        customFontFamily: family,
      }));
      Alert.alert('Font applied', `${asset.name} is now available to the launcher.`);
    } catch {
      Alert.alert('Could not load font', 'Choose a valid .ttf or .otf font file.');
    }
  };

  const resetAppAppearance = (app: LauncherApp) => {
    const renamedApps = { ...data.renamedApps };
    const customIcons = { ...data.customIcons };
    delete renamedApps[app.packageName];
    delete customIcons[app.packageName];
    changeData((current) => ({ ...current, renamedApps, customIcons }));
    setAppMenu(null);
  };

  const openAppSettings = async (app: LauncherApp) => {
    if (!nativeLauncher) {
      Alert.alert('Android build required', 'App details open from Android settings in the installed launcher.');
      return;
    }
    try {
      await nativeLauncher.openAppInfo(app.packageName);
    } catch {
      Alert.alert('Could not open app info', 'Android settings could not open this app.');
    }
    setAppMenu(null);
  };

  const uninstall = (app: LauncherApp) => {
    Alert.alert(`Uninstall ${displayName(app)}?`, 'Android will ask you to confirm before removing the app.', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Continue',
        style: 'destructive',
        onPress: () => {
          if (nativeLauncher) void nativeLauncher.uninstallApp(app.packageName).catch(() => Alert.alert('Could not start uninstall'));
          else Alert.alert('Android build required', 'Uninstall actions are available in the installed Android launcher.');
          setAppMenu(null);
        },
      },
    ]);
  };

  const openNativeSetting = async (method: 'home' | 'notifications' | 'usage' | 'accessibility') => {
    if (!nativeLauncher) {
      Alert.alert('Android build required', 'This system permission can be enabled from the installed Android launcher.');
      return;
    }
    try {
      if (method === 'home') await nativeLauncher.openHomeSettings();
      if (method === 'notifications') await nativeLauncher.openNotificationAccessSettings();
      if (method === 'usage') await nativeLauncher.openUsageAccessSettings();
      if (method === 'accessibility') await nativeLauncher.openAccessibilitySettings();
    } catch {
      Alert.alert('Could not open Android settings', 'Open the matching permission page in Android Settings.');
    }
  };

  const tryLockScreen = async () => {
    if (!nativeLauncher) {
      Alert.alert('Android build required', 'Screen lock is available in the installed Android launcher after enabling its accessibility service.');
      return;
    }
    try {
      const locked = await nativeLauncher.lockScreen();
      if (!locked) {
        Alert.alert('Enable screen-lock access', 'Turn on Swift Launcher screen lock in Android Accessibility settings.', [
          { text: 'Cancel', style: 'cancel' },
          { text: 'Open settings', onPress: () => void openNativeSetting('accessibility') },
        ]);
      }
    } catch {
      Alert.alert('Could not lock screen', 'Enable the launcher accessibility service in Android Settings first.');
    }
  };

  const onFeatureToggle = (key: FeatureKey, value: boolean) => {
    changeData((current) => ({ ...current, settings: { ...current.settings, [key]: value } }));
    if (!value) return;
    if (key === 'weather') {
      void loadWeather(true);
      return;
    }
    if (key === 'calendarAgenda' || key === 'calendarPreview') {
      void requestCalendarAccess();
      return;
    }
    if (unavailableInBuild[key]) {
      Alert.alert('Preference saved', unavailableInBuild[key] || 'This feature is not available in this build yet.');
      return;
    }
    if (['notificationPreviews', 'notificationSummary', 'mediaPlayer', 'quickReplies'].includes(key)) {
      Alert.alert('Notification access', 'Allow Swift Launcher in Android notification access settings to use this feature.', [
        { text: 'Later', style: 'cancel' },
        { text: 'Open settings', onPress: () => void openNativeSetting('notifications') },
      ]);
    } else if (['suggestions', 'usageBreaker', 'digitalWellbeing'].includes(key)) {
      Alert.alert('Usage access', 'Allow usage access so the launcher can learn which apps you use most.', [
        { text: 'Later', style: 'cancel' },
        { text: 'Open settings', onPress: () => void openNativeSetting('usage') },
      ]);
    } else if (['doubleTapToLock', 'quickLock'].includes(key)) {
      Alert.alert('Accessibility service', 'Screen-lock gestures need the launcher accessibility service enabled in Android Settings.', [
        { text: 'Later', style: 'cancel' },
        { text: 'Open settings', onPress: () => void openNativeSetting('accessibility') },
      ]);
    } else if (key === 'appPassword' && !pin) {
      Alert.alert('Set a PIN', 'Create a launcher PIN before protecting apps.', [
        { text: 'Later', style: 'cancel' },
        {
          text: 'Set PIN',
          onPress: () => {
            setPinPurpose('app');
            setPinEntry('');
            setDialog('pin');
          },
        },
      ]);
    } else if (key === 'swipeActions') {
      Alert.alert('Swipe actions', 'Hold an app, choose "Swipe action", then swipe that app sideways to run it.');
    } else if (key === 'dualApps') {
      Alert.alert('Dual apps', 'Android only shares work and dual-app profiles with your default home app. Make Swift Launcher your home app, then reopen it.');
    } else if (key === 'sesameSearch') {
      Alert.alert('Sesame search', 'A Sesame button now appears next to the app list search. It opens Sesame Search & Shortcuts if it is installed.');
    } else if (key === 'pullDownShade') {
      Alert.alert('Android system limit', 'Pulling down the notification shade relies on a hidden system API and may not work on your device.');
    } else if (key === 'iconPacks') {
      void openIconPackPicker();
    } else if (key === 'bluetoothShortcuts') {
      Alert.alert('Bluetooth shortcuts', 'Open Settings → Bluetooth shortcuts to choose which apps appear when a paired device connects.');
    } else if (key === 'musicApps') {
      Alert.alert('Music apps', 'Music apps now appear on the home screen whenever headphones or a Bluetooth audio device are connected.');
    } else if (['homeWidgets'].includes(key)) {
      Alert.alert('Android support varies', platformNotes[key] || 'This feature needs Android-specific support and may not be available on every device.');
    }
  };

  const runSwipe = (app: LauncherApp) => {
    const action = data.swipeActions[app.packageName];
    if (!action) return;
    void Haptics.selectionAsync().catch(() => undefined);
    if (action.type === 'favorite') toggleFavorite(app);
    else if (action.type === 'appinfo') void openAppSettings(app);
    else if (action.type === 'hide') toggleHiddenApp(app);
    else if (action.type === 'lock') void tryLockScreen();
    else if (action.type === 'launch') {
      const target = apps.find((item) => item.packageName === action.target);
      if (target) void launch(target);
      else Alert.alert('App not found', 'The app assigned to this swipe is no longer installed.');
    }
  };

  const setSwipeAction = (app: LauncherApp, action: SwipeAction | null) => {
    changeData((current) => {
      const swipeActions = { ...current.swipeActions };
      if (action) swipeActions[app.packageName] = action;
      else delete swipeActions[app.packageName];
      return { ...current, swipeActions };
    });
    setDialog(null);
    setAppMenu(null);
  };

  const openSesame = () => {
    const sesame = apps.find((app) => /sesame/i.test(app.name));
    if (sesame) void launch(sesame);
    else Alert.alert('Sesame not found', 'Install Sesame Search & Shortcuts from the Play Store, then try again.');
  };

  const updateWidget = (patch: Partial<WidgetSettings>) => {
    changeData((current) => ({ ...current, widget: { ...current.widget, ...patch } }));
  };

  const openNews = () => {
    Linking.openURL('https://news.google.com').catch(() =>
      Alert.alert('Could not open Google News', 'No app or browser could open the news page.'),
    );
  };

  const toggleLockedApp = (app: LauncherApp) => {
    changeData((current) => ({
      ...current,
      settings: { ...current.settings, appPassword: true },
      lockedApps: current.lockedApps.includes(app.packageName)
        ? current.lockedApps.filter((id) => id !== app.packageName)
        : [...current.lockedApps, app.packageName],
    }));
  };

  const doBackup = async () => {
    try {
      const backup = { ...data, customFontUri: undefined, customFontFamily: undefined };
      await Clipboard.setStringAsync(JSON.stringify(backup));
      Alert.alert('Backup copied', 'Launcher settings and folder names were copied. The PIN and chosen photo/font files are not included.');
    } catch {
      Alert.alert('Could not copy backup', 'Clipboard access is unavailable.');
    }
  };

  const doRestore = async () => {
    try {
      const value = await Clipboard.getStringAsync();
      const parsed = JSON.parse(value) as Partial<LauncherData>;
      if (!parsed || typeof parsed !== 'object' || !parsed.settings || !Array.isArray(parsed.favorites)) {
        throw new Error('Invalid backup');
      }
      const restored: LauncherData = {
        ...defaultLauncherData,
        ...parsed,
        settings: { ...defaultLauncherData.settings, ...(parsed.settings || {}) },
        hiddenApps: Array.isArray(parsed.hiddenApps) ? parsed.hiddenApps : [],
        renamedApps: parsed.renamedApps || {},
        customIcons: parsed.customIcons || {},
        lockedApps: parsed.lockedApps || [],
        folders: Array.isArray(parsed.folders) ? parsed.folders : [],
      };
      Alert.alert(
        'Replace current launcher settings?',
        'Restoring this backup replaces your current favorites, app names, hidden apps, folders, and feature switches.',
        [
          { text: 'Cancel', style: 'cancel' },
          {
            text: 'Restore backup',
            style: 'destructive',
            onPress: () => {
              persist(restored);
              Alert.alert('Backup restored', 'Launcher preferences were restored from the clipboard.');
            },
          },
        ],
      );
    } catch {
      Alert.alert('Could not restore backup', 'Clipboard does not contain a valid Swift Launcher backup.');
    }
  };

  const removeFolder = (folder: LauncherFolder) => {
    Alert.alert(`Delete ${folder.name}?`, 'Apps inside the folder will remain installed.', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete folder',
        style: 'destructive',
        onPress: () =>
          changeData((current) => ({
            ...current,
            folders: current.folders.filter((item) => item.id !== folder.id),
          })),
      },
    ]);
  };

  const drawerItems = useMemo<DrawerItem[]>(
    () =>
      sections.flatMap((section) => [
        { kind: 'header' as const, key: `header-${section.title}`, title: section.title },
        ...section.data.map((app) => ({ kind: 'app' as const, key: app.packageName, app })),
      ]),
    [sections],
  );

  const drawerLayout = useMemo(() => {
    const offsets: number[] = [];
    const starts: { title: string; offset: number }[] = [];
    let y = 0;
    drawerItems.forEach((item, index) => {
      offsets[index] = y;
      if (item.kind === 'header') {
        starts.push({ title: item.title, offset: y });
        y += HEADER_H;
      } else {
        y += ROW_H;
      }
    });
    return { offsets, starts };
  }, [drawerItems]);

  const jumpToLetter = (letter: string) => {
    try {
      let offset = 0;
      if (letter) {
        const target =
          drawerLayout.starts.find((entry) => entry.title !== '#' && entry.title >= letter) ??
          drawerLayout.starts[drawerLayout.starts.length - 1];
        if (!target) return;
        offset = target.offset;
      }
      drawerList.current?.scrollToOffset({ offset, animated: false });
    } catch {
      // The list can change between a touch and the scroll; ignoring keeps the launcher running.
    }
  };

  const scrubTo = (pageY: number) => {
    const height = Math.max(scrubberHeight, 1);
    const slots = letters.length + 1;
    const slot = Math.min(slots - 1, Math.max(0, Math.floor(((pageY - scrubberTop.current) / height) * slots)));
    if (slot === lastScrubSlot.current) return;
    lastScrubSlot.current = slot;
    setScrubLetter(slot === 0 ? '★' : letters[slot - 1]);
    void Haptics.selectionAsync().catch(() => undefined);
    jumpToLetter(slot === 0 ? '' : letters[slot - 1]);
  };

  const endScrub = () => {
    lastScrubSlot.current = -1;
    setScrubLetter(null);
  };

  const scrubberPan = useMemo(
    () =>
      PanResponder.create({
        onStartShouldSetPanResponder: () => true,
        onMoveShouldSetPanResponder: () => true,
        onPanResponderTerminationRequest: () => false,
        onPanResponderGrant: (event) => {
          const pageY = event.nativeEvent.pageY;
          scrubberRef.current?.measureInWindow((_x, y) => {
            scrubberTop.current = y;
            scrubTo(pageY);
          });
        },
        onPanResponderMove: (_, gesture) => scrubTo(gesture.moveY),
        onPanResponderRelease: endScrub,
        onPanResponderTerminate: endScrub,
      }),
    [scrubberHeight, drawerLayout],
  );

  const homeGestureCondition = (gesture: { dx: number; dy: number }) =>
    screen === 'home' && !calculatorOpen && Math.abs(gesture.dy) > 16 && Math.abs(gesture.dy) > Math.abs(gesture.dx) * 1.5;

  const listGesture = useMemo(
    () =>
      PanResponder.create({
        // With a short favorites list nothing scrolls, so claim vertical swipes first and
        // make swipe-up reliable even when the finger starts on an app row.
        onMoveShouldSetPanResponderCapture: (_, gesture) => favoriteApps.length <= 6 && homeGestureCondition(gesture),
        onMoveShouldSetPanResponder: (_, gesture) => homeGestureCondition(gesture),
        onPanResponderTerminationRequest: () => false,
        onPanResponderRelease: (_, gesture) => {
          if (gesture.dy < -55 || (gesture.dy < -28 && gesture.vy < -0.8)) {
            openDrawer();
            return;
          }
          if (gesture.dy > 75 && data.settings.pullDownShade) {
            if (nativeLauncher) {
              void nativeLauncher.expandNotificationShade().then((opened) => {
                if (!opened) {
                  Alert.alert('Android system limit', 'Your device did not allow the notification shade gesture. Support depends on Android version and manufacturer.');
                }
              });
            } else {
              Alert.alert('Android build required', 'The notification shade gesture is only attempted in the installed Android launcher.');
            }
          }
        },
      }),
    [data.settings.pullDownShade, screen, calculatorOpen, favoriteApps.length],
  );

  const safeLeft = data.settings.leftHanded;
  const appRow = (app: LauncherApp, favorite = false) => (
    <AppRow
      key={app.packageName}
      app={app}
      label={displayName(app)}
      iconUri={data.customIcons[app.packageName] || iconUris[app.packageName]}
      notification={
        (data.settings.notificationPreviews ? notifications[app.packageName] : undefined) ||
        (data.settings.calendarPreview && /calendar/i.test(app.packageName) && agenda[0]
          ? `Next: ${agenda[0].title || 'Event'} · ${agenda[0].allDay ? 'All day' : new Date(agenda[0].begin).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}`
          : undefined)
      }
      favorite={favorite}
      showIcons={data.settings.showIcons}
      colors={colors}
      iconPack={data.settings.iconPacks ? data.iconPack : undefined}
      onSwipe={data.settings.swipeActions && data.swipeActions[app.packageName] ? () => runSwipe(app) : undefined}
      onPress={() => void launch(app)}
      onLongPress={() => {
        setAppMenu(app);
        setDialog(null);
      }}
    />
  );

  const renderHeader = (title: string, onBack: () => void, right?: React.ReactNode) => (
    <View style={[styles.pageHeader, { paddingTop: Math.max(insets.top, Platform.OS === 'web' ? 67 : 12) }]}>
      <Pressable onPress={onBack} accessibilityRole="button" accessibilityLabel="Back" style={styles.headerIcon}>
        <Feather name="arrow-left" size={21} color={colors.foreground} />
      </Pressable>
      <Text numberOfLines={1} style={[styles.pageTitle, { color: colors.foreground }]}>{title}</Text>
      <View style={styles.headerRight}>{right}</View>
    </View>
  );

  const featureRow = (
    key: FeatureKey,
    label: string,
    detail: string,
    access?: string,
  ) => {
    const queryMatches = !settingQuery || `${label} ${detail} ${access || ''}`.toLowerCase().includes(settingQuery);
    if (!queryMatches) return null;
    return (
      <View key={key} style={[styles.featureRow, { borderBottomColor: colors.border }]}>
        <View style={styles.featureCopy}>
          <Text style={[styles.featureLabel, { color: colors.foreground }]}>{label}</Text>
          <Text style={[styles.featureDetail, { color: colors.mutedForeground }]}>{detail}</Text>
          {access ? (
            <Text style={[styles.accessLabel, { color: colors.primary }]}>{access}</Text>
          ) : null}
          {unavailableInBuild[key] ? (
            <Text style={[styles.accessLabel, { color: colors.mutedForeground }]}>NOT IN THIS BUILD YET</Text>
          ) : null}
        </View>
        <Switch
          accessibilityLabel={`Toggle ${label}`}
          value={data.settings[key]}
          onValueChange={(value) => onFeatureToggle(key, value)}
          trackColor={{ false: colors.border, true: colors.primary }}
          thumbColor={colors.background}
          style={styles.featureSwitch}
        />
      </View>
    );
  };

  const settingsBody = () => (
    <>
      <View style={styles.settingsIdentity}>
        <View style={[styles.brandMark, { backgroundColor: colors.accent }]}>
          <Feather name="wind" size={22} color={colors.primary} />
        </View>
        <Text style={[styles.brandName, { color: colors.foreground }]}>Swift Launcher</Text>
        <Text style={[styles.brandSubtitle, { color: colors.mutedForeground }]}>
          {isNativeLauncherAvailable ? 'Android launcher' : 'Interactive preview'}
        </Text>
      </View>
      <Pressable
        onPress={() => void openNativeSetting('home')}
        style={[styles.homeRoleCard, { backgroundColor: colors.accent }]}
      >
        <View style={styles.homeRoleCopy}>
          <Text style={[styles.homeRoleTitle, { color: colors.accentForeground }]}>Make this your home app</Text>
          <Text style={[styles.homeRoleDetail, { color: colors.accentForeground }]}>
            Choose Swift Launcher as the default Android home screen.
          </Text>
        </View>
        <Feather name="arrow-up-right" size={18} color={colors.accentForeground} />
      </Pressable>
      <TextInput
        value={settingSearch}
        onChangeText={setSettingSearch}
        placeholder="Find a setting"
        placeholderTextColor={colors.mutedForeground}
        style={[styles.searchInput, { backgroundColor: colors.card, color: colors.foreground, borderColor: colors.border }]}
        returnKeyType="search"
      />
      {featureGroups.map((group) => {
        const rows = group.features
          .map((item) => featureRow(item.key, item.label, item.detail, 'access' in item ? item.access : undefined))
          .filter(Boolean);
        if (rows.length === 0) return null;
        return (
          <View key={group.title} style={styles.settingsGroup}>
            <Text style={[styles.sectionEyebrow, { color: colors.mutedForeground }]}>{group.title.toUpperCase()}</Text>
            <View style={[styles.settingsCard, { backgroundColor: colors.background }]}>
              {rows}
            </View>
            {group.title === 'Personalization' && data.settings.iconPacks ? (
              <View style={styles.fontChoiceRow}>
                <View style={styles.featureCopy}>
                  <Text style={[styles.featureLabel, { color: colors.foreground }]}>Icon pack</Text>
                  <Text style={[styles.featureDetail, { color: colors.mutedForeground }]}>
                    {data.iconPack ? `Using ${iconPackList.find((pack) => pack.packageName === data.iconPack)?.name || data.iconPack}` : 'System icons'}
                  </Text>
                </View>
                <Pressable onPress={() => void openIconPackPicker()} style={[styles.smallIconButton, { backgroundColor: colors.accent }]} accessibilityLabel="Choose icon pack">
                  <Feather name="grid" size={16} color={colors.accentForeground} />
                </Pressable>
              </View>
            ) : null}
            {group.title === 'Personalization' && data.settings.customFont ? (
              <View style={styles.fontChoiceRow}>
                <View style={styles.featureCopy}>
                  <Text style={[styles.featureLabel, { color: colors.foreground }]}>Custom typeface</Text>
                  <Text style={[styles.featureDetail, { color: colors.mutedForeground }]}>
                    {customFontFamily ? 'A custom font is active on this device.' : 'Choose a .ttf or .otf font file.'}
                  </Text>
                </View>
                <Pressable onPress={() => void chooseCustomFont()} style={[styles.smallIconButton, { backgroundColor: colors.accent }]}>
                  <Feather name="upload" size={16} color={colors.accentForeground} />
                </Pressable>
                {customFontFamily ? (
                  <Pressable
                    onPress={() => {
                      setCustomFontFamily(null);
                      changeData((current) => ({ ...current, customFontUri: undefined, customFontFamily: undefined }));
                    }}
                    style={styles.smallIconButton}
                    accessibilityLabel="Reset custom font"
                  >
                    <Feather name="rotate-ccw" size={15} color={colors.mutedForeground} />
                  </Pressable>
                ) : null}
              </View>
            ) : null}
          </View>
        );
      })}
      {data.settings.bluetoothShortcuts ? (
        <Pressable
          onPress={() => setScreen('bluetooth')}
          style={[styles.settingsLink, { borderTopColor: colors.border }]}
        >
          <View style={[styles.settingsLinkIcon, { backgroundColor: colors.card }]}>
            <Feather name="bluetooth" size={17} color={colors.foreground} />
          </View>
          <View style={styles.featureCopy}>
            <Text style={[styles.featureLabel, { color: colors.foreground }]}>Bluetooth shortcuts</Text>
            <Text style={[styles.featureDetail, { color: colors.mutedForeground }]}>Apps to show when a device connects</Text>
          </View>
          <Feather name="chevron-right" size={17} color={colors.mutedForeground} />
        </Pressable>
      ) : null}
      {data.settings.digitalWellbeing || data.settings.usageBreaker ? (
        <Pressable
          onPress={() => setScreen('wellbeing')}
          style={[styles.settingsLink, { borderTopColor: colors.border }]}
        >
          <View style={[styles.settingsLinkIcon, { backgroundColor: colors.card }]}>
            <Feather name="activity" size={17} color={colors.foreground} />
          </View>
          <View style={styles.featureCopy}>
            <Text style={[styles.featureLabel, { color: colors.foreground }]}>Screen time</Text>
            <Text style={[styles.featureDetail, { color: colors.mutedForeground }]}>Today's app usage and break reminders</Text>
          </View>
          <Feather name="chevron-right" size={17} color={colors.mutedForeground} />
        </Pressable>
      ) : null}
      <Pressable
        onPress={() => setDialog('widget')}
        style={[styles.settingsLink, { borderTopColor: colors.border }]}
      >
        <View style={[styles.settingsLinkIcon, { backgroundColor: colors.card }]}>
          <Feather name="clock" size={17} color={colors.foreground} />
        </View>
        <View style={styles.featureCopy}>
          <Text style={[styles.featureLabel, { color: colors.foreground }]}>Clock widget</Text>
          <Text style={[styles.featureDetail, { color: colors.mutedForeground }]}>Size, time format, and alignment</Text>
        </View>
        <Feather name="chevron-right" size={17} color={colors.mutedForeground} />
      </Pressable>
      <Pressable
        onPress={() => setScreen('advanced')}
        style={[styles.settingsLink, { borderTopColor: colors.border }]}
      >
        <View style={[styles.settingsLinkIcon, { backgroundColor: colors.card }]}>
          <Feather name="sliders" size={17} color={colors.foreground} />
        </View>
        <View style={styles.featureCopy}>
          <Text style={[styles.featureLabel, { color: colors.foreground }]}>Advanced</Text>
          <Text style={[styles.featureDetail, { color: colors.mutedForeground }]}>Hidden apps, security, and backup</Text>
        </View>
        <Feather name="chevron-right" size={17} color={colors.mutedForeground} />
      </Pressable>
    </>
  );

  const showAppMenu = () => {
    if (!appMenu) return null;
    const app = appMenu;
    const isFavorite = data.favorites.includes(app.packageName);
    const action = (label: string, icon: keyof typeof Feather.glyphMap, onPress: () => void, destructive = false) => (
      <Pressable
        key={label}
        onPress={onPress}
        style={({ pressed }) => [styles.menuAction, pressed && styles.pressed]}
      >
        <Feather name={icon} size={18} color={destructive ? colors.destructive : colors.foreground} />
        <Text style={[styles.menuActionText, { color: destructive ? colors.destructive : colors.foreground }]}>{label}</Text>
      </Pressable>
    );
    return (
      <View style={styles.overlay}>
        <Pressable style={StyleSheet.absoluteFill} onPress={() => setAppMenu(null)} />
        <View style={[styles.actionSheet, { backgroundColor: colors.background, paddingBottom: Math.max(insets.bottom, 18) }]}>
          <View style={[styles.sheetHandle, { backgroundColor: colors.border }]} />
          <Text style={[styles.sheetTitle, { color: colors.foreground }]}>{displayName(app)}</Text>
          <Text numberOfLines={1} style={[styles.sheetSubtitle, { color: colors.mutedForeground }]}>{app.packageName}</Text>
          <ScrollView style={styles.sheetScroll} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
          {action(isFavorite ? 'Remove from favorites' : 'Add to favorites', isFavorite ? 'star' : 'star', () => toggleFavorite(app))}
          {action('Rename app', 'edit-2', () => {
            setDraft(data.renamedApps[app.packageName] || app.name);
            setDialog('rename');
          })}
          {action('Change icon', 'image', () => void chooseCustomIcon())}
          {data.settings.swipeActions ? action('Swipe action…', 'chevrons-right', () => setDialog('swipe')) : null}
          {data.customIcons[app.packageName] || data.renamedApps[app.packageName]
            ? action('Reset name & icon', 'rotate-ccw', () => resetAppAppearance(app))
            : null}
          {data.settings.folders ? action('Add to folder…', 'folder-plus', () => {
            setFolderTarget(app.packageName);
            setDraft('');
            setDialog('folder');
          }) : null}
          {action(
            data.lockedApps.includes(app.packageName) ? 'Remove app PIN' : 'Lock app with PIN',
            'lock',
            () => {
              if (!pin) {
                setPinPurpose('app');
                setPinEntry('');
                setDialog('pin');
              } else {
                toggleLockedApp(app);
                setAppMenu(null);
              }
            },
          )}
          {action('App info', 'info', () => void openAppSettings(app))}
          {action('Hide app', 'eye-off', () => toggleHiddenApp(app))}
          {action('Uninstall', 'trash-2', () => uninstall(app), true)}
          </ScrollView>
        </View>
      </View>
    );
  };

  const showDialog = () => {
    if (!dialog) return null;
    const title =
      dialog === 'iconpack' ? 'Icon pack'
      : dialog === 'bt-apps' ? 'Apps for this device'
      : dialog === 'swipe' ? 'Swipe action'
      : dialog === 'swipe-app' ? 'Open which app?'
      : dialog === 'widget' ? 'Clock widget'
      : dialog === 'rename' ? 'Rename app'
        : dialog === 'folder' ? 'Add to folder'
          : dialog === 'pin' ? 'Create launcher PIN'
            : dialog === 'unlock' ? (pinPurpose === 'remove' ? 'Remove PIN' : pinPurpose === 'change' ? 'Enter current PIN' : 'Enter launcher PIN')
              : dialog === 'restore' ? 'Restore backup'
                : dialog === 'folder-apps' ? 'Choose apps'
                  : '';
    return (
      <KeyboardAvoidingView behavior="padding" style={[styles.overlay, styles.dialogOverlay]}>
        <Pressable style={StyleSheet.absoluteFill} onPress={() => { Keyboard.dismiss(); setDialog(null); }} />
        <View style={[styles.dialogCard, { backgroundColor: colors.background, marginBottom: Math.max(insets.bottom, 14) }]}>
          <Text style={[styles.dialogTitle, { color: colors.foreground }]}>{title}</Text>
          {dialog === 'iconpack' ? (
            <>
              <ScrollView style={{ maxHeight: 360 }}>
                {[{ packageName: '', name: 'System icons' }, ...iconPackList].map((pack) => {
                  const active = (data.iconPack || '') === pack.packageName;
                  return (
                    <Pressable
                      key={pack.packageName || 'system'}
                      onPress={() => {
                        changeData((current) => ({ ...current, iconPack: pack.packageName || undefined }));
                        setDialog(null);
                      }}
                      style={[styles.folderChoice, { borderColor: colors.border }]}
                    >
                      <Text style={[styles.folderChoiceText, { color: colors.foreground }]}>{pack.name}</Text>
                      {active ? <Feather name="check" size={17} color={colors.primary} /> : null}
                    </Pressable>
                  );
                })}
              </ScrollView>
              <View style={styles.dialogActions}>
                <Pressable onPress={() => setDialog(null)}><Text style={[styles.textButton, { color: colors.mutedForeground }]}>Close</Text></Pressable>
              </View>
            </>
          ) : dialog === 'bt-apps' && btTarget ? (
            <>
              <Text style={[styles.dialogHint, { color: colors.mutedForeground }]}>
                These apps appear on the home screen while {btTarget.name} is connected.
              </Text>
              <ScrollView style={{ maxHeight: 340 }} keyboardShouldPersistTaps="handled">
                {visibleApps.map((app) => {
                  const rule = data.bluetoothRules.find((item) => item.address === btTarget.address);
                  const included = Boolean(rule?.appIds.includes(app.packageName));
                  return (
                    <Pressable
                      key={app.packageName}
                      onPress={() =>
                        changeData((current) => {
                          const existing = current.bluetoothRules.find((item) => item.address === btTarget.address);
                          const next: BluetoothRule = existing
                            ? {
                                ...existing,
                                appIds: included
                                  ? existing.appIds.filter((id) => id !== app.packageName)
                                  : [...existing.appIds, app.packageName],
                              }
                            : { address: btTarget.address, name: btTarget.name, appIds: [app.packageName] };
                          return {
                            ...current,
                            bluetoothRules: existing
                              ? current.bluetoothRules.map((item) => (item.address === btTarget.address ? next : item))
                              : [...current.bluetoothRules, next],
                          };
                        })
                      }
                      style={[styles.folderChoice, { borderColor: colors.border }]}
                    >
                      <Text style={[styles.folderChoiceText, { color: colors.foreground }]}>{displayName(app)}</Text>
                      {included ? <Feather name="check" size={17} color={colors.primary} /> : <Feather name="plus" size={17} color={colors.mutedForeground} />}
                    </Pressable>
                  );
                })}
              </ScrollView>
              <View style={styles.dialogActions}>
                <Pressable onPress={() => setDialog(null)}><Text style={[styles.textButton, { color: colors.primary }]}>Done</Text></Pressable>
              </View>
            </>
          ) : dialog === 'swipe' && appMenu ? (
            <>
              <Text style={[styles.dialogHint, { color: colors.mutedForeground }]}>
                Choose what happens when you swipe {displayName(appMenu)} sideways.
              </Text>
              {([
                ['No action', null],
                ['Toggle favorite', { type: 'favorite' }],
                ['Open app info', { type: 'appinfo' }],
                ['Hide app', { type: 'hide' }],
                ['Lock screen', { type: 'lock' }],
              ] as const).map(([label, value]) => (
                <Pressable
                  key={label}
                  onPress={() => setSwipeAction(appMenu, value as SwipeAction | null)}
                  style={[styles.folderChoice, { borderColor: colors.border }]}
                >
                  <Text style={[styles.folderChoiceText, { color: colors.foreground }]}>{label}</Text>
                  {(data.swipeActions[appMenu.packageName]?.type ?? null) === (value?.type ?? null) ? (
                    <Feather name="check" size={17} color={colors.primary} />
                  ) : null}
                </Pressable>
              ))}
              <Pressable onPress={() => setDialog('swipe-app')} style={[styles.folderChoice, { borderColor: colors.border }]}>
                <Text style={[styles.folderChoiceText, { color: colors.foreground }]}>Open another app…</Text>
                <Feather name="chevron-right" size={17} color={colors.mutedForeground} />
              </Pressable>
              <View style={styles.dialogActions}>
                <Pressable onPress={() => setDialog(null)}><Text style={[styles.textButton, { color: colors.mutedForeground }]}>Cancel</Text></Pressable>
              </View>
            </>
          ) : dialog === 'swipe-app' && appMenu ? (
            <>
              <ScrollView style={{ maxHeight: 360 }} keyboardShouldPersistTaps="handled">
                {visibleApps
                  .filter((item) => item.packageName !== appMenu.packageName)
                  .map((item) => (
                    <Pressable
                      key={item.packageName}
                      onPress={() => setSwipeAction(appMenu, { type: 'launch', target: item.packageName })}
                      style={[styles.folderChoice, { borderColor: colors.border }]}
                    >
                      <Text style={[styles.folderChoiceText, { color: colors.foreground }]}>{displayName(item)}</Text>
                    </Pressable>
                  ))}
              </ScrollView>
              <View style={styles.dialogActions}>
                <Pressable onPress={() => setDialog('swipe')}><Text style={[styles.textButton, { color: colors.mutedForeground }]}>Back</Text></Pressable>
              </View>
            </>
          ) : dialog === 'widget' ? (
            <>
              <Text style={[styles.dialogHint, { color: colors.mutedForeground }]}>Size</Text>
              <View style={styles.chipRow}>
                {([['S', 0.75], ['M', 1], ['L', 1.4], ['XL', 1.8]] as const).map(([label, value]) => {
                  const active = Math.abs(data.widget.scale - value) < 0.05;
                  return (
                    <Pressable
                      key={label}
                      onPress={() => updateWidget({ scale: value })}
                      style={[styles.chip, { backgroundColor: active ? colors.primary : colors.card }]}
                    >
                      <Text style={[styles.chipText, { color: active ? colors.primaryForeground : colors.foreground }]}>{label}</Text>
                    </Pressable>
                  );
                })}
              </View>
              <View style={styles.stepperRow}>
                <Pressable
                  onPress={() => updateWidget({ scale: Math.max(0.6, Math.round((data.widget.scale - 0.1) * 100) / 100) })}
                  style={[styles.stepperButton, { backgroundColor: colors.card }]}
                  accessibilityLabel="Make clock smaller"
                >
                  <Feather name="minus" size={18} color={colors.foreground} />
                </Pressable>
                <Text style={[styles.stepperValue, { color: colors.foreground }]}>{Math.round(data.widget.scale * 100)}%</Text>
                <Pressable
                  onPress={() => updateWidget({ scale: Math.min(2, Math.round((data.widget.scale + 0.1) * 100) / 100) })}
                  style={[styles.stepperButton, { backgroundColor: colors.card }]}
                  accessibilityLabel="Make clock larger"
                >
                  <Feather name="plus" size={18} color={colors.foreground} />
                </Pressable>
              </View>
              <Text style={[styles.dialogHint, { color: colors.mutedForeground }]}>Time format</Text>
              <View style={styles.chipRow}>
                {([['Auto', 'auto'], ['12-hour', '12h'], ['24-hour', '24h']] as const).map(([label, value]) => {
                  const active = data.widget.format === value;
                  return (
                    <Pressable
                      key={value}
                      onPress={() => updateWidget({ format: value })}
                      style={[styles.chip, { backgroundColor: active ? colors.primary : colors.card }]}
                    >
                      <Text style={[styles.chipText, { color: active ? colors.primaryForeground : colors.foreground }]}>{label}</Text>
                    </Pressable>
                  );
                })}
              </View>
              <View style={styles.dialogSwitchRow}>
                <Text style={[styles.featureLabel, { color: colors.foreground }]}>Show date</Text>
                <Switch
                  value={data.widget.showDate}
                  onValueChange={(value) => updateWidget({ showDate: value })}
                  trackColor={{ false: colors.border, true: colors.primary }}
                  thumbColor={colors.background}
                />
              </View>
              <View style={styles.dialogSwitchRow}>
                <Text style={[styles.featureLabel, { color: colors.foreground }]}>Center on screen</Text>
                <Switch
                  value={data.widget.centered}
                  onValueChange={(value) => updateWidget({ centered: value })}
                  trackColor={{ false: colors.border, true: colors.primary }}
                  thumbColor={colors.background}
                />
              </View>
              <View style={styles.dialogActions}>
                <Pressable onPress={() => updateWidget(defaultWidget)}><Text style={[styles.textButton, { color: colors.mutedForeground }]}>Reset</Text></Pressable>
                <Pressable onPress={() => setDialog(null)}><Text style={[styles.textButton, { color: colors.primary }]}>Done</Text></Pressable>
              </View>
            </>
          ) : dialog === 'folder' ? (
            <>
              {appMenu ? data.folders.filter((folder) => !folder.hidden).map((folder) => (
                <Pressable
                  key={folder.id}
                  onPress={() => moveToFolder(folder)}
                  style={[styles.folderChoice, { borderColor: colors.border }]}
                >
                  <Feather name="folder" size={17} color={colors.primary} />
                  <Text style={[styles.folderChoiceText, { color: colors.foreground }]}>{folder.name}</Text>
                </Pressable>
              )) : null}
              <TextInput
                value={draft}
                onChangeText={setDraft}
                placeholder="New folder name"
                placeholderTextColor={colors.mutedForeground}
                style={[styles.dialogInput, { color: colors.foreground, borderColor: colors.border, backgroundColor: colors.card }]}
                autoFocus
              />
              <View style={styles.dialogActions}>
                <Pressable onPress={() => setDialog(null)}><Text style={[styles.textButton, { color: colors.mutedForeground }]}>Cancel</Text></Pressable>
                {appMenu ? <Pressable onPress={() => createFolder(false)}><Text style={[styles.textButton, { color: colors.primary }]}>New folder</Text></Pressable> : null}
                {hiddenOpen ? <Pressable onPress={() => createFolder(true)}><Text style={[styles.textButton, { color: colors.primary }]}>New hidden folder</Text></Pressable> : null}
              </View>
            </>
          ) : dialog === 'folder-apps' ? (
            <>
              <ScrollView style={{ maxHeight: 360 }}>
                {visibleApps.map((app) => {
                  const folder = data.folders.find((item) => item.id === appPickerFolderId);
                  const included = folder?.appIds.includes(app.packageName);
                  return (
                    <Pressable
                      key={app.packageName}
                      onPress={() => {
                        changeData((current) => ({
                          ...current,
                          folders: current.folders.map((item) =>
                            item.id !== appPickerFolderId
                              ? item
                              : { ...item, appIds: included ? item.appIds.filter((id) => id !== app.packageName) : [...item.appIds, app.packageName] },
                          ),
                        }));
                      }}
                      style={[styles.folderChoice, { borderColor: colors.border }]}
                    >
                      <Text style={[styles.folderChoiceText, { color: colors.foreground }]}>{displayName(app)}</Text>
                      {included ? <Feather name="check" size={17} color={colors.primary} /> : <Feather name="plus" size={17} color={colors.mutedForeground} />}
                    </Pressable>
                  );
                })}
              </ScrollView>
              <Pressable onPress={() => setDialog(null)} style={styles.dialogActions}><Text style={[styles.textButton, { color: colors.primary }]}>Done</Text></Pressable>
            </>
          ) : dialog === 'rename' ? (
            <>
              <TextInput
                value={draft}
                onChangeText={setDraft}
                placeholder="App name"
                placeholderTextColor={colors.mutedForeground}
                style={[styles.dialogInput, { color: colors.foreground, borderColor: colors.border, backgroundColor: colors.card }]}
                autoFocus
                selectTextOnFocus
              />
              <View style={styles.dialogActions}>
                <Pressable onPress={() => setDialog(null)}><Text style={[styles.textButton, { color: colors.mutedForeground }]}>Cancel</Text></Pressable>
                <Pressable onPress={saveRename}><Text style={[styles.textButton, { color: colors.primary }]}>Save</Text></Pressable>
              </View>
            </>
          ) : dialog === 'pin' || dialog === 'unlock' ? (
            <>
              <Text style={[styles.dialogHint, { color: colors.mutedForeground }]}>
                {dialog === 'pin'
                  ? 'Use 4–8 digits. The PIN is stored in Android secure storage.'
                  : pinPurpose === 'remove'
                    ? 'Enter your current PIN to turn PIN protection off. Locked apps will open without a PIN.'
                    : pinPurpose === 'change'
                      ? 'Enter your current PIN, then choose a new one.'
                      : pinPurpose === 'app'
                        ? 'This app is protected by your launcher PIN.'
                        : 'This folder is hidden from the home screen and protected by your launcher PIN.'}
              </Text>
              <TextInput
                value={pinEntry}
                onChangeText={setPinEntry}
                placeholder="••••"
                placeholderTextColor={colors.mutedForeground}
                keyboardType="number-pad"
                secureTextEntry
                maxLength={8}
                style={[styles.pinInput, { color: colors.foreground, borderColor: colors.border, backgroundColor: colors.card }]}
                autoFocus
              />
              <View style={styles.dialogActions}>
                <Pressable onPress={() => setDialog(null)}><Text style={[styles.textButton, { color: colors.mutedForeground }]}>Cancel</Text></Pressable>
                <Pressable onPress={() => void (dialog === 'pin' ? saveNewPin() : launchWithPin())}>
                  <Text style={[styles.textButton, { color: colors.primary }]}>
                    {dialog === 'pin' ? 'Set PIN' : pinPurpose === 'remove' ? 'Remove' : pinPurpose === 'change' ? 'Continue' : 'Unlock'}
                  </Text>
                </Pressable>
              </View>
            </>
          ) : (
            <Pressable onPress={() => setDialog(null)} style={styles.dialogActions}>
              <Text style={[styles.textButton, { color: colors.primary }]}>Close</Text>
            </Pressable>
          )}
        </View>
      </KeyboardAvoidingView>
    );
  };

  const homeScreen = () => {
    const suggestions = [...new Set([...suggestedIds, ...recentIds])]
      .filter((id) => !data.favorites.includes(id) && !data.hiddenApps.includes(id))
      .map((id) => apps.find((app) => app.packageName === id))
      .filter((app): app is LauncherApp => Boolean(app))
      .slice(0, 3);
    return (
      <View style={[styles.homePage, { paddingTop: Math.max(insets.top, Platform.OS === 'web' ? 67 : 14), paddingBottom: Math.max(insets.bottom, Platform.OS === 'web' ? 34 : 16) }]} {...listGesture.panHandlers}>
        <View style={styles.homeTopBar}>
          <View style={{ flex: 1, alignItems: data.widget.centered ? 'center' : 'flex-start' }}>
            <Pressable
              onLongPress={() => setDialog('widget')}
              delayLongPress={420}
              onPress={() => {
                if (!data.settings.doubleTapToLock) return;
                const now = Date.now();
                if (now - lastClockTap.current < 360) {
                  lastClockTap.current = 0;
                  void tryLockScreen();
                } else {
                  lastClockTap.current = now;
                }
              }}
              accessibilityLabel={data.settings.doubleTapToLock ? 'Double tap the clock to lock screen' : undefined}
            >
            <Text
              numberOfLines={1}
              adjustsFontSizeToFit
              style={[
                styles.timeText,
                { color: colors.foreground, fontSize: 47 * data.widget.scale, lineHeight: 54 * data.widget.scale },
              ]}
            >
              {time.toLocaleTimeString([], {
                hour: 'numeric',
                minute: '2-digit',
                ...(data.widget.format === 'auto' ? {} : { hour12: data.widget.format === '12h' }),
              })}
            </Text>
            </Pressable>
            {data.widget.showDate ? (
              <Text style={[styles.dateText, { color: colors.mutedForeground, fontSize: 15 * (0.85 + 0.15 * data.widget.scale) }]}>
                {time.toLocaleDateString([], { weekday: 'short', day: 'numeric', month: 'short' })}
              </Text>
            ) : null}
            {data.settings.doubleTapToLock ? (
              <Text style={[styles.lockHint, { color: colors.mutedForeground }]}>Double-tap the clock to lock</Text>
            ) : null}
          </View>
          <View style={styles.topActions}>
            {data.settings.googleNews ? (
              <Pressable onPress={openNews} style={styles.roundIconButton} accessibilityLabel="Open Google News">
                <Feather name="globe" size={18} color={colors.foreground} />
              </Pressable>
            ) : null}
            {data.settings.quickLock ? (
              <Pressable onPress={() => void tryLockScreen()} style={styles.roundIconButton} accessibilityLabel="Lock screen">
                <Feather name="lock" size={18} color={colors.foreground} />
              </Pressable>
            ) : null}
          </View>
        </View>

        {data.settings.calendarAgenda ? (
          <Pressable
            onPress={() => {
              if (!calendarGranted) void requestCalendarAccess();
            }}
            style={[styles.agendaCard, { backgroundColor: colors.card }]}
          >
            <Feather name="calendar" size={16} color={colors.primary} />
            <View style={styles.agendaBody}>
              {!calendarGranted ? (
                <Text style={[styles.agendaLine, { color: colors.mutedForeground }]}>Tap to allow calendar access for your agenda.</Text>
              ) : agenda.length === 0 ? (
                <Text style={[styles.agendaLine, { color: colors.mutedForeground }]}>No upcoming events.</Text>
              ) : (
                agenda.slice(0, 2).map((event, index) => (
                  <Text key={`${event.begin}-${index}`} numberOfLines={1} style={[styles.agendaLine, { color: index === 0 ? colors.foreground : colors.mutedForeground }]}>
                    {event.allDay
                      ? 'All day'
                      : new Date(event.begin).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}
                    {'  '}
                    {event.title || 'Untitled event'}
                  </Text>
                ))
              )}
            </View>
          </Pressable>
        ) : null}
        {data.settings.digitalWellbeing && nativeLauncher?.hasUsageAccess() ? (
          <Pressable onPress={() => setScreen('wellbeing')} style={[styles.agendaCard, { backgroundColor: colors.card }]}>
            <Feather name="activity" size={16} color={colors.primary} />
            <Text style={[styles.agendaText, { color: colors.mutedForeground }]}>
              Screen time today: {formatDuration(Object.values(usageToday).reduce((sum, ms) => sum + ms, 0))}
            </Text>
          </Pressable>
        ) : null}

        {data.settings.notificationSummary ? (
          <Pressable
            onPress={() => {
              let hasAccess = true;
              try {
                hasAccess = nativeLauncher ? nativeLauncher.hasNotificationAccess() : false;
              } catch {
                hasAccess = false;
              }
              if (!hasAccess) void openNativeSetting('notifications');
            }}
            style={[styles.agendaCard, { backgroundColor: colors.card }]}
          >
            <Feather name="bell" size={16} color={colors.primary} />
            <Text style={[styles.agendaText, { color: colors.mutedForeground }]}>
              {(() => {
                const ids = Object.keys(notifications).filter((id) => !data.hiddenApps.includes(id));
                let hasAccess = false;
                try {
                  hasAccess = nativeLauncher ? nativeLauncher.hasNotificationAccess() : false;
                } catch {
                  hasAccess = false;
                }
                if (!hasAccess) return 'Tap to allow notification access for the summary.';
                if (ids.length === 0) return 'No new notifications.';
                const names = ids
                  .map((id) => apps.find((app) => app.packageName === id))
                  .filter((app): app is LauncherApp => Boolean(app))
                  .map((app) => displayName(app));
                const shown = names.slice(0, 3).join(', ');
                const extra = names.length > 3 ? ` +${names.length - 3}` : '';
                return `${ids.length} app${ids.length === 1 ? '' : 's'} with notifications: ${shown}${extra}`;
              })()}
            </Text>
          </Pressable>
        ) : null}

        {favoriteApps.length ? (
          <View style={[styles.homeList, safeLeft && styles.homeListLeft]}>
            <View style={styles.homeListSpacer} />
            <ScrollView
              contentContainerStyle={styles.homeListContent}
              showsVerticalScrollIndicator={false}
              scrollEnabled={favoriteApps.length > 6}
            >
              {favoriteApps.map((app) => appRow(app, true))}
            </ScrollView>
          </View>
        ) : (
          <View style={styles.homeEmpty}>
            <Text style={[styles.homeEmptyTitle, { color: colors.foreground }]}>Your home, kept simple.</Text>
            <Text style={[styles.homeEmptyCopy, { color: colors.mutedForeground }]}>
              Open the app list and hold an app to add it to favorites.
            </Text>
          </View>
        )}

        {data.settings.suggestions && suggestions.length > 0 ? (
          <View style={styles.suggestionsBlock}>
            <Text style={[styles.sectionEyebrow, { color: colors.mutedForeground }]}>OFTEN USED</Text>
            {suggestions.map((app) => appRow(app))}
          </View>
        ) : null}
        {data.settings.bluetoothShortcuts
          ? data.bluetoothRules
              .filter((rule) => btConnected.some((device) => device.address === rule.address))
              .map((rule) => {
                const ruleApps = rule.appIds
                  .map((id) => apps.find((app) => app.packageName === id))
                  .filter((app): app is LauncherApp => Boolean(app) && !data.hiddenApps.includes(app!.packageName))
                  .slice(0, 3);
                if (ruleApps.length === 0) return null;
                return (
                  <View key={rule.address} style={styles.suggestionsBlock}>
                    <Text style={[styles.sectionEyebrow, { color: colors.mutedForeground }]}>{`WITH ${rule.name}`.toUpperCase()}</Text>
                    {ruleApps.map((app) => appRow(app))}
                  </View>
                );
              })
          : null}
        {data.settings.musicApps && headphones ? (() => {
          const musicApps = apps
            .filter((app) => MUSIC_PATTERN.test(app.name) || MUSIC_PATTERN.test(app.packageName))
            .filter((app) => !data.hiddenApps.includes(app.packageName))
            .slice(0, 3);
          if (musicApps.length === 0) return null;
          return (
            <View style={styles.suggestionsBlock}>
              <Text style={[styles.sectionEyebrow, { color: colors.mutedForeground }]}>HEADPHONES CONNECTED</Text>
              {musicApps.map((app) => appRow(app))}
            </View>
          );
        })() : null}
        {data.settings.folders && visibleFolders.length > 0 ? (
          <View style={styles.homeFolders}>
            {visibleFolders.map((folder) => (
              <Pressable
                key={folder.id}
                onPress={() => setActiveFolder(folder)}
                onLongPress={() => removeFolder(folder)}
                style={[styles.folderPill, { backgroundColor: colors.card }]}
              >
                <Feather name="folder" size={15} color={colors.primary} />
                <Text style={[styles.folderPillText, { color: colors.foreground }]}>{folder.name}</Text>
                <Text style={[styles.folderCount, { color: colors.mutedForeground }]}>{folder.appIds.length}</Text>
              </Pressable>
            ))}
          </View>
        ) : null}
        {data.settings.weather ? (
          weather.status === 'ready' ? (
            <View style={[styles.weatherHint, { borderColor: colors.border }]}>
              <Feather name={weatherInfo(weather.code).icon} size={17} color={colors.primary} />
              <Text style={[styles.weatherHintText, { color: colors.foreground }]}>
                {weather.temp}{weather.unit} · {weatherInfo(weather.code).label}
              </Text>
              <Text style={[styles.weatherRange, { color: colors.mutedForeground }]}>
                H {weather.high}° · L {weather.low}°
              </Text>
            </View>
          ) : (
            <Pressable
              onPress={() => void loadWeather(true)}
              style={[styles.weatherHint, { borderColor: colors.border }]}
            >
              <Feather name="cloud" size={15} color={colors.mutedForeground} />
              <Text style={[styles.weatherHintText, { color: colors.mutedForeground }]}>
                {weather.status === 'denied'
                  ? 'Tap to allow location for the weather forecast.'
                  : weather.status === 'error'
                    ? 'Weather unavailable. Tap to try again.'
                    : 'Loading weather…'}
              </Text>
            </Pressable>
          )
        ) : null}

        <View style={styles.homeBottom}>
          {isDemo ? <Text style={[styles.demoTag, { color: colors.mutedForeground }]}>DEMO APP LIST</Text> : null}
          <Pressable onPress={openDrawer} style={[styles.appListButton, { backgroundColor: colors.card }]}>
            <Feather name="grid" size={16} color={colors.primary} />
            <Text style={[styles.appListButtonText, { color: colors.foreground }]}>All apps</Text>
            <Feather name="arrow-up" size={15} color={colors.mutedForeground} />
          </Pressable>
          <Text style={[styles.swipeHint, { color: colors.mutedForeground }]}>Swipe up for all apps · hold the clock to resize it</Text>
        </View>
      </View>
    );
  };

  const drawerScreen = () => (
    <View style={[styles.drawerPage, { paddingTop: Math.max(insets.top, Platform.OS === 'web' ? 67 : 12), paddingBottom: Math.max(insets.bottom, Platform.OS === 'web' ? 34 : 10) }]}>
      <View style={styles.drawerHeader}>
        <Pressable onPress={goHome} style={styles.headerIcon} accessibilityLabel="Back to home">
          <Feather name="arrow-left" size={21} color={colors.foreground} />
        </Pressable>
        {data.settings.sesameSearch ? (
          <Pressable onPress={openSesame} style={styles.headerIcon} accessibilityLabel="Open Sesame search">
            <Feather name="compass" size={20} color={colors.primary} />
          </Pressable>
        ) : null}
        <TextInput
          value={search}
          onChangeText={setSearch}
          placeholder={`Search ${apps.length} apps`}
          placeholderTextColor={colors.mutedForeground}
          style={[styles.drawerSearch, { backgroundColor: colors.card, color: colors.foreground }]}
          returnKeyType="search"
          clearButtonMode="while-editing"
        />
      </View>
      {appError ? <Text style={[styles.errorNote, { color: colors.destructive }]}>{appError}</Text> : null}
      {isDemo ? <Text style={[styles.demoNotice, { color: colors.mutedForeground }]}>Preview list · installed apps appear in the Android build</Text> : null}
      {sections.length ? (
        <View style={styles.drawerListWrap}>
          <FlatList
            ref={drawerList}
            data={drawerItems}
            keyExtractor={(item) => item.key}
            renderItem={({ item }) =>
              item.kind === 'header' ? (
                <Text style={[styles.sectionLetter, { color: colors.foreground }]}>{item.title}</Text>
              ) : (
                appRow(item.app, data.favorites.includes(item.app.packageName))
              )
            }
            getItemLayout={(_, index) => ({
              length: drawerItems[index]?.kind === 'header' ? HEADER_H : ROW_H,
              offset: drawerLayout.offsets[index] ?? 0,
              index,
            })}
            initialNumToRender={20}
            maxToRenderPerBatch={16}
            windowSize={11}
            keyboardShouldPersistTaps="handled"
            showsVerticalScrollIndicator={false}
            contentContainerStyle={[styles.drawerListContent, safeLeft && styles.drawerListContentLeft]}
          />
          {!search ? (
            <View
              ref={scrubberRef}
              onLayout={(event: LayoutChangeEvent) => {
                setScrubberHeight(event.nativeEvent.layout.height);
                scrubberRef.current?.measureInWindow((_x, y) => {
                  scrubberTop.current = y;
                });
              }}
              style={[styles.scrubber, safeLeft && styles.scrubberLeft]}
              {...scrubberPan.panHandlers}
            >
              <View pointerEvents="none" style={styles.scrubberInner}>
                <Feather name="star" size={13} color={colors.primary} />
                {letters.map((letter) => (
                  <Text
                    key={letter}
                    style={[
                      styles.scrubberLetter,
                      { color: scrubLetter === letter ? colors.primary : colors.foreground },
                    ]}
                  >
                    {letter}
                  </Text>
                ))}
              </View>
            </View>
          ) : null}
          {scrubLetter ? (
            <View pointerEvents="none" style={[styles.scrubBubble, { backgroundColor: colors.primary }]}>
              <Text style={[styles.scrubBubbleText, { color: colors.primaryForeground }]}>{scrubLetter}</Text>
            </View>
          ) : null}
        </View>
      ) : (
        <View style={styles.emptyState}>
          <Feather name="search" size={23} color={colors.mutedForeground} />
          <Text style={[styles.emptyTitle, { color: colors.foreground }]}>{search ? 'No matching apps' : 'No apps to show'}</Text>
          <Text style={[styles.emptyCopy, { color: colors.mutedForeground }]}>
            {search ? 'Try another name.' : 'Hidden apps can be restored in Settings → Advanced.'}
          </Text>
        </View>
      )}
      <Pressable
        onPress={() => setScreen('settings')}
        accessibilityRole="button"
        style={[styles.drawerSettingsButton, { backgroundColor: colors.card }]}
      >
        <Feather name="settings" size={18} color={colors.primary} />
        <Text style={[styles.drawerSettingsText, { color: colors.foreground }]}>Settings</Text>
        <Feather name="chevron-right" size={17} color={colors.mutedForeground} />
      </Pressable>
    </View>
  );

  const bluetoothScreen = () => (
    <View style={[styles.page, { paddingBottom: Math.max(insets.bottom, 18) }]}>
      {renderHeader('Bluetooth shortcuts', () => setScreen('settings'))}
      <ScrollView contentContainerStyle={styles.advancedContent}>
        {!btAllowed ? (
          <Pressable onPress={() => void loadPairedDevices()} style={[styles.securityCard, { backgroundColor: colors.accent }]}>
            <Feather name="bluetooth" size={22} color={colors.primary} />
            <Text style={[styles.securityTitle, { color: colors.accentForeground }]}>Allow Bluetooth access</Text>
            <Text style={[styles.securityDescription, { color: colors.accentForeground }]}>
              Swift Launcher needs the nearby devices permission to list the devices you have paired. Tap to allow it.
            </Text>
          </Pressable>
        ) : (
          <>
            <Text style={[styles.sectionEyebrow, { color: colors.mutedForeground }]}>PAIRED DEVICES</Text>
            {btPaired.map((device) => {
              const rule = data.bluetoothRules.find((item) => item.address === device.address);
              const connected = btConnected.some((item) => item.address === device.address);
              return (
                <Pressable
                  key={device.address}
                  onPress={() => {
                    setBtTarget(device);
                    setDialog('bt-apps');
                  }}
                  style={[styles.settingsLink, { borderTopColor: colors.border }]}
                >
                  <View style={[styles.settingsLinkIcon, { backgroundColor: colors.card }]}>
                    <Feather name="bluetooth" size={17} color={connected ? colors.primary : colors.foreground} />
                  </View>
                  <View style={styles.featureCopy}>
                    <Text style={[styles.featureLabel, { color: colors.foreground }]}>{device.name}</Text>
                    <Text style={[styles.featureDetail, { color: colors.mutedForeground }]}>
                      {connected ? 'Connected · ' : ''}{rule ? `${rule.appIds.length} app${rule.appIds.length === 1 ? '' : 's'} chosen` : 'Tap to choose apps'}
                    </Text>
                  </View>
                  <Feather name="chevron-right" size={17} color={colors.mutedForeground} />
                </Pressable>
              );
            })}
            {btPaired.length === 0 ? (
              <Text style={[styles.emptyCopy, { color: colors.mutedForeground }]}>No paired devices found. Pair a device in Android Bluetooth settings first.</Text>
            ) : null}
          </>
        )}
        <Text style={[styles.featureDetail, { color: colors.mutedForeground, marginTop: 22 }]}>
          Connection status can take a few seconds to update, and only devices that connect while the launcher is running are tracked.
        </Text>
      </ScrollView>
    </View>
  );

  const wellbeingScreen = () => {
    const entries = Object.entries(usageToday).sort((a, b) => b[1] - a[1]);
    const total = entries.reduce((sum, [, ms]) => sum + ms, 0);
    const top = entries.slice(0, 10);
    const longest = top[0]?.[1] || 1;
    let hasAccess = false;
    try {
      hasAccess = nativeLauncher ? nativeLauncher.hasUsageAccess() : false;
    } catch {
      hasAccess = false;
    }
    return (
      <View style={[styles.page, { paddingBottom: Math.max(insets.bottom, 18) }]}>
        {renderHeader('Screen time', () => setScreen('settings'))}
        <ScrollView contentContainerStyle={styles.advancedContent}>
          {!hasAccess ? (
            <Pressable onPress={() => void openNativeSetting('usage')} style={[styles.securityCard, { backgroundColor: colors.accent }]}>
              <Feather name="activity" size={22} color={colors.primary} />
              <Text style={[styles.securityTitle, { color: colors.accentForeground }]}>Allow usage access</Text>
              <Text style={[styles.securityDescription, { color: colors.accentForeground }]}>
                Android only shares app usage with launchers you allow. Tap to open the setting, then choose Swift Launcher.
              </Text>
            </Pressable>
          ) : (
            <>
              <Text style={[styles.sectionEyebrow, { color: colors.mutedForeground }]}>TODAY</Text>
              <Text style={[styles.timeText, { color: colors.foreground, fontSize: 40 }]}>{formatDuration(total)}</Text>
              <Text style={[styles.featureDetail, { color: colors.mutedForeground, marginBottom: 18 }]}>total time in apps since midnight</Text>
              {top.map(([id, ms]) => {
                const app = apps.find((item) => item.packageName === id);
                return (
                  <View key={id} style={styles.usageRow}>
                    <View style={styles.usageLine}>
                      <Text numberOfLines={1} style={[styles.featureLabel, { color: colors.foreground, flex: 1 }]}>{app ? displayName(app) : id}</Text>
                      <Text style={[styles.featureDetail, { color: colors.mutedForeground }]}>{formatDuration(ms)}</Text>
                    </View>
                    <View style={[styles.usageTrack, { backgroundColor: colors.card }]}>
                      <View style={[styles.usageFill, { backgroundColor: colors.primary, width: `${Math.max(4, (ms / longest) * 100)}%` }]} />
                    </View>
                  </View>
                );
              })}
              {top.length === 0 ? <Text style={[styles.emptyCopy, { color: colors.mutedForeground }]}>No app usage recorded yet today.</Text> : null}
            </>
          )}
          {data.settings.usageBreaker ? (
            <>
              <Text style={[styles.sectionEyebrow, { color: colors.mutedForeground, marginTop: 26 }]}>BREAK REMINDER</Text>
              <Text style={[styles.featureDetail, { color: colors.mutedForeground }]}>Remind me after this much total time in apps today.</Text>
              <View style={[styles.stepperRow, { marginTop: 14 }]}>
                <Pressable
                  onPress={() => changeData((current) => ({ ...current, wellbeing: { dailyLimitMinutes: Math.max(15, current.wellbeing.dailyLimitMinutes - 15) } }))}
                  style={[styles.stepperButton, { backgroundColor: colors.card }]}
                  accessibilityLabel="Shorter limit"
                >
                  <Feather name="minus" size={18} color={colors.foreground} />
                </Pressable>
                <Text style={[styles.stepperValue, { color: colors.foreground, minWidth: 90 }]}>{formatDuration(data.wellbeing.dailyLimitMinutes * 60000)}</Text>
                <Pressable
                  onPress={() => changeData((current) => ({ ...current, wellbeing: { dailyLimitMinutes: Math.min(720, current.wellbeing.dailyLimitMinutes + 15) } }))}
                  style={[styles.stepperButton, { backgroundColor: colors.card }]}
                  accessibilityLabel="Longer limit"
                >
                  <Feather name="plus" size={18} color={colors.foreground} />
                </Pressable>
              </View>
            </>
          ) : null}
        </ScrollView>
      </View>
    );
  };

  const advancedScreen = () => (
    <View style={[styles.page, { paddingBottom: Math.max(insets.bottom, 18) }]}>
      {renderHeader('Advanced', () => setScreen('settings'))}
      <ScrollView contentContainerStyle={styles.advancedContent}>
        <Text style={[styles.sectionEyebrow, { color: colors.mutedForeground }]}>PRIVACY</Text>
        <Pressable onPress={() => setScreen('security')} style={[styles.settingsLink, { borderTopColor: colors.border }]}>
          <View style={[styles.settingsLinkIcon, { backgroundColor: colors.card }]}><Feather name="shield" size={17} color={colors.foreground} /></View>
          <View style={styles.featureCopy}>
            <Text style={[styles.featureLabel, { color: colors.foreground }]}>Security & PIN</Text>
            <Text style={[styles.featureDetail, { color: colors.mutedForeground }]}>PIN, locked apps, and hidden folders</Text>
          </View>
          <Feather name="chevron-right" size={17} color={colors.mutedForeground} />
        </Pressable>
        <Pressable onPress={() => setScreen('hidden')} style={[styles.settingsLink, { borderTopColor: colors.border }]}>
          <View style={[styles.settingsLinkIcon, { backgroundColor: colors.card }]}><Feather name="eye-off" size={17} color={colors.foreground} /></View>
          <View style={styles.featureCopy}>
            <Text style={[styles.featureLabel, { color: colors.foreground }]}>Hidden apps</Text>
            <Text style={[styles.featureDetail, { color: colors.mutedForeground }]}>{data.hiddenApps.length} hidden · restore apps here</Text>
          </View>
          <Feather name="chevron-right" size={17} color={colors.mutedForeground} />
        </Pressable>
        {hiddenRevealCount >= 7 ? (
          <Pressable onPress={() => openPinDialog('hidden')} style={[styles.settingsLink, { borderTopColor: colors.border }]}>
            <View style={[styles.settingsLinkIcon, { backgroundColor: colors.card }]}><Feather name="lock" size={17} color={colors.foreground} /></View>
            <View style={styles.featureCopy}>
              <Text style={[styles.featureLabel, { color: colors.foreground }]}>Private folders</Text>
              <Text style={[styles.featureDetail, { color: colors.mutedForeground }]}>PIN protected · hidden from home and drawer</Text>
            </View>
            <Feather name="chevron-right" size={17} color={colors.mutedForeground} />
          </Pressable>
        ) : null}
        <Text style={[styles.sectionEyebrow, { color: colors.mutedForeground, marginTop: 28 }]}>DATA</Text>
        {data.settings.backupRestore ? (
          <>
            <Pressable onPress={() => void doBackup()} style={[styles.settingsLink, { borderTopColor: colors.border }]}>
              <View style={[styles.settingsLinkIcon, { backgroundColor: colors.card }]}><Feather name="copy" size={17} color={colors.foreground} /></View>
              <View style={styles.featureCopy}>
                <Text style={[styles.featureLabel, { color: colors.foreground }]}>Copy backup</Text>
                <Text style={[styles.featureDetail, { color: colors.mutedForeground }]}>Copy favorites, settings, and folders to clipboard</Text>
              </View>
              <Feather name="arrow-up-right" size={16} color={colors.mutedForeground} />
            </Pressable>
            <Pressable onPress={() => void doRestore()} style={[styles.settingsLink, { borderTopColor: colors.border }]}>
              <View style={[styles.settingsLinkIcon, { backgroundColor: colors.card }]}><Feather name="clipboard" size={17} color={colors.foreground} /></View>
              <View style={styles.featureCopy}>
                <Text style={[styles.featureLabel, { color: colors.foreground }]}>Restore from clipboard</Text>
                <Text style={[styles.featureDetail, { color: colors.mutedForeground }]}>Replace current launcher preferences</Text>
              </View>
              <Feather name="arrow-down-left" size={16} color={colors.mutedForeground} />
            </Pressable>
          </>
        ) : null}
        <Pressable
          onPress={() => {
            setHiddenRevealCount((count) => count + 1);
            if (hiddenRevealCount >= 6) Alert.alert('Private folders unlocked', 'The private folders option is now visible on this page.');
          }}
          style={[styles.buildVersion, { borderTopColor: colors.border }]}
        >
          <Text style={[styles.buildVersionText, { color: colors.mutedForeground }]}>Build 1.0.0</Text>
        </Pressable>
      </ScrollView>
    </View>
  );

  const securityScreen = () => (
    <View style={[styles.page, { paddingBottom: Math.max(insets.bottom, 18) }]}>
      {renderHeader('Security & PIN', () => setScreen('advanced'))}
      <ScrollView contentContainerStyle={styles.advancedContent}>
        <View style={[styles.securityCard, { backgroundColor: colors.accent }]}>
          <Feather name="shield" size={22} color={colors.primary} />
          <Text style={[styles.securityTitle, { color: colors.accentForeground }]}>{pin ? 'PIN is set' : 'Set a launcher PIN'}</Text>
          <Text style={[styles.securityDescription, { color: colors.accentForeground }]}>
            The PIN is stored securely on this device and is not included in backups. This protects launcher screens only; Android Settings can still open installed apps.
          </Text>
          <Pressable
            onPress={() => {
              setPinEntry('');
              if (pin) {
                setPinPurpose('change');
                setDialog('unlock');
              } else {
                setPinPurpose('app');
                setDialog('pin');
              }
            }}
            style={[styles.secondaryButton, { backgroundColor: colors.background }]}
          >
            <Text style={[styles.secondaryButtonText, { color: colors.foreground }]}>{pin ? 'Change PIN' : 'Create PIN'}</Text>
          </Pressable>
          {pin ? (
            <Pressable
              onPress={() => {
                setPinPurpose('remove');
                setPinEntry('');
                setDialog('unlock');
              }}
              style={[styles.secondaryButton, { backgroundColor: colors.background, marginTop: 10 }]}
              accessibilityLabel="Remove PIN"
            >
              <Text style={[styles.secondaryButtonText, { color: colors.destructive }]}>Remove PIN</Text>
            </Pressable>
          ) : null}
        </View>
        <Text style={[styles.sectionEyebrow, { color: colors.mutedForeground }]}>LOCKED APPS</Text>
        {apps.filter((app) => !data.hiddenApps.includes(app.packageName)).map((app) => (
          <Pressable
            key={app.packageName}
            onPress={() => {
              if (!pin) {
                Alert.alert('Set a PIN first', 'Create a PIN before protecting apps.');
                return;
              }
              toggleLockedApp(app);
            }}
            style={[styles.settingsLink, { borderTopColor: colors.border }]}
          >
            <View style={[styles.settingsLinkIcon, { backgroundColor: colors.card }]}>
              <Feather name={data.lockedApps.includes(app.packageName) ? 'lock' : 'smartphone'} size={17} color={colors.foreground} />
            </View>
            <View style={styles.featureCopy}>
              <Text style={[styles.featureLabel, { color: colors.foreground }]}>{displayName(app)}</Text>
              <Text style={[styles.featureDetail, { color: colors.mutedForeground }]}>{data.lockedApps.includes(app.packageName) ? 'PIN required to open' : 'Tap to protect this app'}</Text>
            </View>
            {data.lockedApps.includes(app.packageName) ? <Feather name="check" size={17} color={colors.primary} /> : null}
          </Pressable>
        ))}
        {pin ? (
          <Pressable
            onPress={() => Alert.alert(
              'Reset PIN and erase private data?',
              'This permanently deletes hidden folders, their app assignments, locked-app selections, and the saved PIN. Installed apps will not be removed.',
              [
                { text: 'Cancel', style: 'cancel' },
                {
                  text: 'Erase and reset',
                  style: 'destructive',
                  onPress: () => {
                    void SecureStore.deleteItemAsync(PIN_KEY).catch(() => undefined);
                    setPin(null);
                    setHiddenOpen(false);
                    changeData((current) => ({
                      ...current,
                      folders: current.folders.filter((folder) => !folder.hidden),
                      lockedApps: [],
                      settings: { ...current.settings, appPassword: false },
                    }));
                  },
                },
              ],
            )}
            style={[styles.resetPinLink, { borderTopColor: colors.border }]}
          >
            <Text style={[styles.featureLabel, { color: colors.destructive }]}>Forgot PIN? Erase private data and reset</Text>
            <Text style={[styles.featureDetail, { color: colors.mutedForeground }]}>This cannot be undone.</Text>
          </Pressable>
        ) : null}
      </ScrollView>
    </View>
  );

  const hiddenScreen = () => (
    <View style={[styles.page, { paddingBottom: Math.max(insets.bottom, 18) }]}>
      {renderHeader(hiddenOpen ? 'Private folders' : 'Hidden apps', () => {
        setScreen('advanced');
        setHiddenOpen(false);
        setActiveFolder(null);
      })}
      {hiddenOpen ? (
        <ScrollView contentContainerStyle={styles.advancedContent}>
          <Text style={[styles.privateNotice, { color: colors.mutedForeground }]}>Only visible after entering your PIN.</Text>
          {!activeFolder ? (
            <>
              {hiddenFolders.map((folder) => (
                <View key={folder.id} style={[styles.privateFolder, { backgroundColor: colors.card }]}>
                  <Pressable onPress={() => setActiveFolder(folder)} style={styles.privateFolderMain}>
                    <Feather name="folder" size={20} color={colors.primary} />
                    <View style={styles.featureCopy}>
                      <Text style={[styles.featureLabel, { color: colors.foreground }]}>{folder.name}</Text>
                      <Text style={[styles.featureDetail, { color: colors.mutedForeground }]}>{folder.appIds.length} apps</Text>
                    </View>
                    <Feather name="chevron-right" size={17} color={colors.mutedForeground} />
                  </Pressable>
                  <Pressable onPress={() => removeFolder(folder)} style={styles.smallIconButton} accessibilityLabel={`Delete ${folder.name}`}>
                    <Feather name="trash-2" size={16} color={colors.mutedForeground} />
                  </Pressable>
                </View>
              ))}
              <Pressable
                onPress={() => {
                  setFolderTarget(null);
                  setDraft('');
                  setDialog('folder');
                }}
                style={[styles.secondaryButton, { backgroundColor: colors.accent }]}
              >
                <Feather name="plus" size={17} color={colors.accentForeground} />
                <Text style={[styles.secondaryButtonText, { color: colors.accentForeground }]}>New hidden folder</Text>
              </Pressable>
              {hiddenFolders.length === 0 ? (
                <Text style={[styles.emptyCopy, { color: colors.mutedForeground, textAlign: 'center', marginTop: 18 }]}>
                  No private folders yet. Create one, open it, then tap the plus button to add apps.
                </Text>
              ) : null}
            </>
          ) : (
            <>
              <View style={styles.folderDetailHeader}>
                <View>
                  <Text style={[styles.folderDetailTitle, { color: colors.foreground }]}>{activeFolder.name}</Text>
                  <Text style={[styles.featureDetail, { color: colors.mutedForeground }]}>{activeFolder.appIds.length} apps</Text>
                </View>
                <Pressable
                  onPress={() => {
                    setAppPickerFolderId(activeFolder.id);
                    setDialog('folder-apps');
                  }}
                  style={[styles.smallIconButton, { backgroundColor: colors.card }]}
                  accessibilityLabel="Add apps"
                >
                  <Feather name="plus" size={18} color={colors.primary} />
                </Pressable>
              </View>
              {activeFolder.appIds.map((id) => {
                const app = apps.find((item) => item.packageName === id);
                return app ? (
                  <View key={id} style={[styles.folderMember, { borderBottomColor: colors.border }]}>
                    <Text style={[styles.folderMemberText, { color: colors.foreground }]}>{displayName(app)}</Text>
                    <Pressable
                      onPress={() => {
                        changeData((current) => ({
                          ...current,
                          folders: current.folders.map((item) =>
                            item.id === activeFolder.id ? { ...item, appIds: item.appIds.filter((appId) => appId !== id) } : item,
                          ),
                        }));
                        setActiveFolder((folder) => folder ? { ...folder, appIds: folder.appIds.filter((appId) => appId !== id) } : null);
                      }}
                      style={styles.smallIconButton}
                      accessibilityLabel={`Remove ${displayName(app)} from folder`}
                    >
                      <Feather name="x" size={16} color={colors.mutedForeground} />
                    </Pressable>
                  </View>
                ) : null;
              })}
            </>
          )}
        </ScrollView>
      ) : (
        <KeyboardAwareScrollViewCompat contentContainerStyle={styles.advancedContent}>
          <Text style={[styles.sectionEyebrow, { color: colors.mutedForeground }]}>HIDDEN APPS</Text>
          {data.hiddenApps.map((id) => {
            const app = apps.find((item) => item.packageName === id);
            return (
              <View key={id} style={[styles.settingsLink, { borderTopColor: colors.border }]}>
                <View style={[styles.settingsLinkIcon, { backgroundColor: colors.card }]}>
                  <Feather name="eye-off" size={16} color={colors.foreground} />
                </View>
                <View style={styles.featureCopy}>
                  <Text style={[styles.featureLabel, { color: colors.foreground }]}>{app ? displayName(app) : id}</Text>
                  <Text style={[styles.featureDetail, { color: colors.mutedForeground }]}>Hidden from launcher search and favorites</Text>
                </View>
                <Pressable
                  onPress={() => {
                    changeData((current) => ({ ...current, hiddenApps: current.hiddenApps.filter((appId) => appId !== id) }));
                  }}
                  style={styles.smallIconButton}
                  accessibilityLabel={`Unhide ${app ? displayName(app) : id}`}
                >
                  <Feather name="eye" size={17} color={colors.primary} />
                </Pressable>
              </View>
            );
          })}
          {data.hiddenApps.length === 0 ? (
            <Text style={[styles.emptyCopy, { color: colors.mutedForeground, marginBottom: 18 }]}>No apps are hidden.</Text>
          ) : null}
          <Text style={[styles.sectionEyebrow, { color: colors.mutedForeground, marginTop: 24 }]}>HIDE AN APP</Text>
          <TextInput
            value={hiddenAppSearch}
            onChangeText={setHiddenAppSearch}
            placeholder="Search installed apps"
            placeholderTextColor={colors.mutedForeground}
            style={[styles.searchInput, { backgroundColor: colors.card, color: colors.foreground, borderColor: colors.border }]}
            returnKeyType="search"
            accessibilityLabel="Search apps to hide"
          />
          {hiddenAppSearch.trim() ? (
            apps
              .filter((app) => !data.hiddenApps.includes(app.packageName))
              .filter((app) => displayName(app).toLocaleLowerCase().includes(hiddenAppSearch.trim().toLocaleLowerCase()))
              .slice(0, 30)
              .map((app) => (
                <Pressable
                  key={app.packageName}
                  onPress={() => toggleHiddenApp(app)}
                  style={[styles.settingsLink, { borderTopColor: colors.border }]}
                >
                  <View style={[styles.settingsLinkIcon, { backgroundColor: colors.card }]}>
                    <Feather name="smartphone" size={16} color={colors.foreground} />
                  </View>
                  <View style={styles.featureCopy}>
                    <Text numberOfLines={1} style={[styles.featureLabel, { color: colors.foreground }]}>{displayName(app)}</Text>
                    <Text style={[styles.featureDetail, { color: colors.mutedForeground }]}>Hide from app list, search, and favorites</Text>
                  </View>
                  <Feather name="eye-off" size={17} color={colors.mutedForeground} />
                </Pressable>
              ))
          ) : (
            <Text style={[styles.emptyCopy, { color: colors.mutedForeground, marginBottom: 14 }]}>Search for an installed app, then tap it to hide it.</Text>
          )}
          {hiddenAppSearch.trim() && !apps.some((app) =>
            !data.hiddenApps.includes(app.packageName) &&
            displayName(app).toLocaleLowerCase().includes(hiddenAppSearch.trim().toLocaleLowerCase()),
          ) ? (
            <Text style={[styles.emptyCopy, { color: colors.mutedForeground, marginBottom: 14 }]}>No installed apps match that search.</Text>
          ) : null}
        </KeyboardAwareScrollViewCompat>
      )}
    </View>
  );

  const folderOverlay = activeFolder && screen === 'home' ? (
    <View style={styles.overlay}>
      <Pressable style={StyleSheet.absoluteFill} onPress={() => setActiveFolder(null)} />
      <View style={[styles.actionSheet, { backgroundColor: colors.background, paddingBottom: Math.max(insets.bottom, 18) }]}>
        <View style={[styles.sheetHandle, { backgroundColor: colors.border }]} />
        <Text style={[styles.sheetTitle, { color: colors.foreground }]}>{activeFolder.name}</Text>
        {activeFolder.appIds.map((id) => {
          const app = apps.find((item) => item.packageName === id);
          return app ? appRow(app) : null;
        })}
        <Pressable onPress={() => removeFolder(activeFolder)} style={styles.menuAction}>
          <Feather name="trash-2" size={17} color={colors.destructive} />
          <Text style={[styles.menuActionText, { color: colors.destructive }]}>Delete folder</Text>
        </Pressable>
      </View>
    </View>
  ) : null;

  const openCalculator = () => setCalculatorOpen(true);
  const calculatorButtons = ['7', '8', '9', '÷', '4', '5', '6', '×', '1', '2', '3', '−', '0', '.', 'C', '+', '='];
  const pressCalculator = (key: string) => {
    if (key === 'C') return setCalculatorValue('');
    if (key === '=') {
      const expression = calculatorValue.replace(/×/g, '*').replace(/÷/g, '/').replace(/−/g, '-');
      const match = expression.match(/^(-?\d+(?:\.\d+)?)([+\-*/])(-?\d+(?:\.\d+)?)$/);
      if (!match) return;
      const left = Number(match[1]);
      const right = Number(match[3]);
      const answer = match[2] === '+' ? left + right
        : match[2] === '-' ? left - right
          : match[2] === '*' ? left * right
            : right === 0 ? NaN : left / right;
      if (Number.isFinite(answer)) setCalculatorValue(String(Number(answer.toFixed(8))));
      return;
    }
    setCalculatorValue((current) => (current.length < 18 ? current + key : current));
  };

  const calculatorModal = (
    <Modal visible={calculatorOpen} transparent animationType="fade" onRequestClose={() => setCalculatorOpen(false)}>
      <View style={[styles.overlay, { justifyContent: 'center', paddingHorizontal: 24 }]}>
        <Pressable style={StyleSheet.absoluteFill} onPress={() => setCalculatorOpen(false)} />
        <View style={[styles.calculatorCard, { backgroundColor: colors.background }]}>
          <View style={styles.calculatorHeader}>
            <Text style={[styles.dialogTitle, { color: colors.foreground }]}>Calculator</Text>
            <Pressable onPress={() => setCalculatorOpen(false)}><Feather name="x" size={20} color={colors.foreground} /></Pressable>
          </View>
          <Text numberOfLines={1} style={[styles.calculatorDisplay, { color: colors.foreground }]}>{calculatorValue || '0'}</Text>
          <View style={styles.calculatorGrid}>
            {calculatorButtons.map((key) => (
              <Pressable
                key={key}
                onPress={() => pressCalculator(key)}
                style={[styles.calculatorKey, { backgroundColor: ['=', '+', '−', '×', '÷'].includes(key) ? colors.accent : colors.card }]}
              >
                <Text style={[styles.calculatorKeyText, { color: ['=', '+', '−', '×', '÷'].includes(key) ? colors.accentForeground : colors.foreground }]}>{key}</Text>
              </Pressable>
            ))}
          </View>
        </View>
      </View>
    </Modal>
  );

  if (!loaded) {
    return <View style={[styles.loadingPage, { backgroundColor: colors.background }]}><Text style={{ color: colors.mutedForeground }}>Starting launcher…</Text></View>;
  }

  return (
    <FontContext.Provider value={data.settings.customFont ? customFontFamily || undefined : undefined}>
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      <StatusBar hidden={data.settings.hideStatusBar} barStyle={colors.foreground === '#f3f4ef' ? 'light-content' : 'dark-content'} />
      {screen === 'home' ? homeScreen() : null}
      {screen === 'drawer' ? drawerScreen() : null}
      {screen === 'settings' ? (
        <View style={[styles.page, { paddingBottom: Math.max(insets.bottom, 18) }]}>
          {renderHeader('Settings', goHome)}
          <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={styles.settingsContent}>
            {settingsBody()}
          </ScrollView>
        </View>
      ) : null}
      {screen === 'advanced' ? advancedScreen() : null}
      {screen === 'wellbeing' ? wellbeingScreen() : null}
      {screen === 'bluetooth' ? bluetoothScreen() : null}
      {screen === 'security' ? securityScreen() : null}
      {screen === 'hidden' ? hiddenScreen() : null}
      {folderOverlay}
      {showAppMenu()}
      {showDialog()}
      {calculatorModal}
      {data.settings.calculator ? (
        <Pressable
          onPress={openCalculator}
          style={[styles.calculatorFab, { backgroundColor: colors.card, bottom: Math.max(insets.bottom, 20) + 62 }]}
          accessibilityLabel="Open calculator"
        >
          <Feather name="hash" size={19} color={colors.primary} />
        </Pressable>
      ) : null}
    </View>
    </FontContext.Provider>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  loadingPage: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  pressed: { opacity: 0.68 },
  homePage: { flex: 1, paddingHorizontal: 24 },
  homeTopBar: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  timeText: { fontSize: 47, lineHeight: 54, fontWeight: '500', letterSpacing: -2 },
  dateText: { fontSize: 15, marginTop: 2, fontWeight: '500' },
  lockHint: { fontSize: 10, marginTop: 4 },
  topActions: { flexDirection: 'row', alignItems: 'center', gap: 5 },
  roundIconButton: { width: 42, height: 42, borderRadius: 21, alignItems: 'center', justifyContent: 'center' },
  homeList: { flex: 1, justifyContent: 'flex-end', paddingVertical: 20 },
  homeListSpacer: { flex: 1 },
  homeListLeft: { alignItems: 'flex-start' },
  homeListContent: { justifyContent: 'flex-end', paddingBottom: 4 },
  appRow: { height: ROW_H, flexDirection: 'row', alignItems: 'center', paddingVertical: 4, gap: 13 },
  appIcon: { width: 38, height: 38, borderRadius: 13, alignItems: 'center', justifyContent: 'center', overflow: 'hidden' },
  appIconImage: { width: 30, height: 30 },
  appInitials: { fontSize: 12, fontWeight: '700', letterSpacing: 0.3 },
  appNameColumn: { flex: 1, minWidth: 0, justifyContent: 'center', gap: 2 },
  appNameLine: { flexDirection: 'row', alignItems: 'center', gap: 7 },
  appName: { fontSize: 18, lineHeight: 24, fontWeight: '500', flexShrink: 1 },
  notificationText: { fontSize: 12, lineHeight: 16 },
  rowTouchMark: { width: 18, alignItems: 'center' },
  homeEmpty: { flex: 1, justifyContent: 'center', paddingHorizontal: 16 },
  homeEmptyTitle: { fontSize: 25, fontWeight: '500', letterSpacing: -0.4 },
  homeEmptyCopy: { fontSize: 15, lineHeight: 22, marginTop: 8, maxWidth: 280 },
  suggestionsBlock: { paddingBottom: 12 },
  sectionEyebrow: { fontSize: 11, letterSpacing: 1.5, fontWeight: '700', marginBottom: 8 },
  homeFolders: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, paddingBottom: 10 },
  folderPill: { flexDirection: 'row', alignItems: 'center', gap: 7, borderRadius: 20, paddingHorizontal: 12, paddingVertical: 9 },
  folderPillText: { fontSize: 13, fontWeight: '500' },
  folderCount: { fontSize: 11 },
  agendaCard: { marginTop: 22, borderRadius: 14, padding: 12, flexDirection: 'row', gap: 9, alignItems: 'center' },
  agendaText: { fontSize: 12, flex: 1 },
  weatherHint: { flexDirection: 'row', alignItems: 'center', gap: 8, paddingVertical: 9, borderTopWidth: StyleSheet.hairlineWidth },
  weatherHintText: { fontSize: 12, flex: 1 },
  homeBottom: { alignItems: 'center', gap: 7, paddingTop: 6 },
  demoTag: { fontSize: 9, letterSpacing: 1.4, fontWeight: '700' },
  appListButton: { minHeight: 46, minWidth: 164, borderRadius: 24, paddingHorizontal: 16, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 11 },
  appListButtonText: { fontSize: 14, fontWeight: '600' },
  swipeHint: { fontSize: 11 },
  drawerPage: { flex: 1, paddingHorizontal: 17 },
  drawerHeader: { flexDirection: 'row', alignItems: 'center', gap: 7, paddingBottom: 8 },
  headerIcon: { width: 38, height: 42, alignItems: 'center', justifyContent: 'center' },
  drawerSearch: { flex: 1, minHeight: 42, borderRadius: 22, paddingHorizontal: 15, fontSize: 15 },
  drawerSettingsButton: { minHeight: 48, borderRadius: 16, flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: 14, marginTop: 8 },
  drawerSettingsText: { flex: 1, fontSize: 14, fontWeight: '600' },
  demoNotice: { fontSize: 11, paddingHorizontal: 7, paddingBottom: 8 },
  errorNote: { fontSize: 12, paddingHorizontal: 7, paddingBottom: 8 },
  drawerListWrap: { flex: 1, position: 'relative' },
  drawerListContent: { paddingRight: 34, paddingBottom: 12 },
  sectionLetter: { fontSize: 16, fontWeight: '700', height: HEADER_H, paddingBottom: 5, textAlignVertical: 'bottom' },
  scrubber: { position: 'absolute', right: -6, top: 5, bottom: 7, width: 32, zIndex: 4 },
  scrubberLeft: { right: undefined, left: -6 },
  scrubberInner: { flex: 1, alignItems: 'center', justifyContent: 'space-between' },
  scrubberLetter: { fontSize: 10, lineHeight: 12, fontWeight: '700' },
  scrubBubble: { position: 'absolute', left: '50%', marginLeft: -36, top: '40%', width: 72, height: 72, borderRadius: 36, alignItems: 'center', justifyContent: 'center', zIndex: 6 },
  scrubBubbleText: { fontSize: 34, fontWeight: '700' },
  drawerListContentLeft: { paddingRight: 0, paddingLeft: 34 },
  sheetScroll: { flexGrow: 0 },
  dialogOverlay: { justifyContent: 'center' },
  chipRow: { flexDirection: 'row', gap: 8, marginBottom: 14, flexWrap: 'wrap' },
  chip: { minWidth: 56, minHeight: 40, borderRadius: 20, paddingHorizontal: 16, alignItems: 'center', justifyContent: 'center' },
  chipText: { fontSize: 14, fontWeight: '600' },
  stepperRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 20, marginBottom: 16 },
  stepperButton: { width: 44, height: 44, borderRadius: 22, alignItems: 'center', justifyContent: 'center' },
  stepperValue: { minWidth: 64, fontSize: 18, fontWeight: '600', textAlign: 'center' },
  dialogSwitchRow: { minHeight: 48, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  weatherRange: { fontSize: 12 },
  agendaBody: { flex: 1, gap: 3 },
  agendaLine: { fontSize: 12 },
  usageRow: { marginBottom: 14 },
  usageLine: { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 6 },
  usageTrack: { height: 6, borderRadius: 3, overflow: 'hidden' },
  usageFill: { height: 6, borderRadius: 3 },
  emptyState: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 10, paddingHorizontal: 28 },
  emptyTitle: { fontSize: 18, fontWeight: '600', textAlign: 'center' },
  emptyCopy: { fontSize: 14, lineHeight: 21, textAlign: 'center' },
  page: { flex: 1 },
  pageHeader: { minHeight: 59, flexDirection: 'row', alignItems: 'center', paddingHorizontal: 17, paddingBottom: 6 },
  pageTitle: { flex: 1, fontSize: 20, fontWeight: '600', letterSpacing: -0.3 },
  headerRight: { minWidth: 36, alignItems: 'flex-end' },
  settingsContent: { paddingHorizontal: 20, paddingBottom: 30 },
  settingsIdentity: { alignItems: 'center', paddingTop: 13, paddingBottom: 22 },
  brandMark: { width: 52, height: 52, borderRadius: 17, alignItems: 'center', justifyContent: 'center', marginBottom: 10 },
  brandName: { fontSize: 24, fontWeight: '500', letterSpacing: -0.5 },
  brandSubtitle: { fontSize: 13, marginTop: 4 },
  homeRoleCard: { borderRadius: 16, padding: 15, flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 14 },
  homeRoleCopy: { flex: 1, gap: 4 },
  homeRoleTitle: { fontSize: 14, fontWeight: '600' },
  homeRoleDetail: { fontSize: 12, lineHeight: 17, opacity: 0.8 },
  searchInput: { minHeight: 43, borderWidth: 1, borderRadius: 14, paddingHorizontal: 14, fontSize: 14, marginBottom: 21 },
  settingsGroup: { marginBottom: 19 },
  fontChoiceRow: { minHeight: 62, flexDirection: 'row', alignItems: 'center', gap: 5, paddingHorizontal: 10, paddingTop: 8 },
  settingsCard: { borderRadius: 17, paddingHorizontal: 14, overflow: 'hidden' },
  featureRow: { minHeight: 68, flexDirection: 'row', alignItems: 'center', borderBottomWidth: StyleSheet.hairlineWidth, paddingVertical: 10, gap: 8 },
  featureCopy: { flex: 1, minWidth: 0, gap: 3 },
  featureLabel: { fontSize: 15, fontWeight: '500' },
  featureDetail: { fontSize: 12, lineHeight: 17 },
  accessLabel: { fontSize: 9, letterSpacing: 0.8, fontWeight: '700', marginTop: 2 },
  featureSwitch: { transform: [{ scale: 0.87 }] },
  settingsLink: { minHeight: 70, borderTopWidth: StyleSheet.hairlineWidth, flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 10, paddingHorizontal: 3 },
  settingsLinkIcon: { width: 36, height: 36, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  advancedContent: { paddingHorizontal: 20, paddingBottom: 26 },
  buildVersion: { marginTop: 32, paddingTop: 15, borderTopWidth: StyleSheet.hairlineWidth, flexDirection: 'row', justifyContent: 'space-between' },
  buildVersionText: { fontSize: 11 },
  buildTapCount: { fontSize: 10 },
  securityCard: { padding: 18, borderRadius: 18, alignItems: 'flex-start', gap: 8, marginBottom: 25 },
  securityTitle: { fontSize: 18, fontWeight: '600' },
  securityDescription: { fontSize: 13, lineHeight: 19, opacity: 0.8 },
  resetPinLink: { borderTopWidth: StyleSheet.hairlineWidth, paddingVertical: 15, marginTop: 16, gap: 4 },
  secondaryButton: { borderRadius: 13, minHeight: 42, paddingHorizontal: 16, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, alignSelf: 'flex-start', marginTop: 6 },
  secondaryButtonText: { fontSize: 13, fontWeight: '600' },
  privateNotice: { fontSize: 12, marginBottom: 13 },
  privateFolder: { borderRadius: 15, minHeight: 63, paddingLeft: 13, paddingRight: 4, marginBottom: 8, flexDirection: 'row', alignItems: 'center' },
  privateFolderMain: { flex: 1, minHeight: 63, flexDirection: 'row', alignItems: 'center', gap: 11 },
  smallIconButton: { width: 38, height: 38, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  folderDetailHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingVertical: 8, marginBottom: 8 },
  folderDetailTitle: { fontSize: 22, fontWeight: '600' },
  folderMember: { minHeight: 52, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', borderBottomWidth: StyleSheet.hairlineWidth },
  folderMemberText: { fontSize: 15 },
  overlay: { ...StyleSheet.absoluteFill, zIndex: 10, backgroundColor: 'rgba(0,0,0,0.32)', justifyContent: 'flex-end' },
  actionSheet: { borderTopLeftRadius: 24, borderTopRightRadius: 24, paddingHorizontal: 22, paddingTop: 11, maxHeight: '86%' },
  sheetHandle: { width: 40, height: 4, borderRadius: 2, alignSelf: 'center', marginBottom: 16 },
  sheetTitle: { fontSize: 20, fontWeight: '600' },
  sheetSubtitle: { fontSize: 11, marginTop: 3, marginBottom: 14 },
  menuAction: { minHeight: 48, flexDirection: 'row', alignItems: 'center', gap: 13 },
  menuActionText: { fontSize: 15, fontWeight: '500' },
  dialogCard: { marginHorizontal: 20, borderRadius: 20, padding: 20 },
  dialogTitle: { fontSize: 19, fontWeight: '600', marginBottom: 8 },
  dialogHint: { fontSize: 13, lineHeight: 19, marginBottom: 15 },
  dialogInput: { minHeight: 47, borderRadius: 12, borderWidth: 1, paddingHorizontal: 13, fontSize: 15, marginTop: 12 },
  pinInput: { minHeight: 55, borderRadius: 14, borderWidth: 1, paddingHorizontal: 16, fontSize: 19, letterSpacing: 5, textAlign: 'center' },
  dialogActions: { minHeight: 48, flexDirection: 'row', alignItems: 'center', justifyContent: 'flex-end', gap: 18, flexWrap: 'wrap', marginTop: 9 },
  textButton: { fontSize: 13, fontWeight: '700' },
  folderChoice: { minHeight: 45, borderBottomWidth: StyleSheet.hairlineWidth, flexDirection: 'row', alignItems: 'center', gap: 10 },
  folderChoiceText: { flex: 1, fontSize: 14 },
  calculatorFab: { position: 'absolute', right: 21, width: 45, height: 45, borderRadius: 23, alignItems: 'center', justifyContent: 'center', elevation: 4 },
  calculatorCard: { borderRadius: 22, padding: 17 },
  calculatorHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  calculatorDisplay: { fontSize: 32, fontWeight: '500', textAlign: 'right', minHeight: 53, marginVertical: 12 },
  calculatorGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 7 },
  calculatorKey: { width: '23%', minHeight: 52, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  calculatorKeyText: { fontSize: 19, fontWeight: '500' },
});
